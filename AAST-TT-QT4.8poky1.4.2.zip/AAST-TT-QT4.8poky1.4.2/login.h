#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include "global.h"

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    void keyPressEvent(QKeyEvent *event);
    void call_login();
    bool eventFilter(QObject *object, QEvent *event);

    ~Login();


private:
    Ui::Login *ui;
signals:
    void callthread();    

private slots:
    void on_pushButton_login_clicked();
    void on_pushButton_cancel_clicked();
    void on_lineEdit_UN_returnPressed();
    void on_lineEdit_PW_returnPressed();

};
#endif // LOGIN_H
