#ifndef TICKET_H
#define TICKET_H

#include <QDialog>
#include <QKeyEvent>

namespace Ui {
    class Ticket;
}

class Ticket : public QDialog
{
    Q_OBJECT

    public:
        explicit Ticket(QWidget *parent,QString moduleId);

        QStringList lst_line_data,lst_line_size,lst_is_bold,lst_is_italic,lst_font_family;
        enum PreView_Alignment
        {
            PreViewAlignment_LEFT ,      /**< Aligns with the left. */
            PreViewAlignment_CENTER ,    /**< Align with center. */
            PreViewAlignment_RIGHT       /**< Aligns with the right. */
        };

        void add_image_data(QString r_const_imageDATA,QString font_family,
                            int font_size, bool isBold, bool is_italic,
                            PreView_Alignment preview_Align = PreViewAlignment_LEFT);

        void creat_image_to_print();

        QImage i1;

        void keyPressEvent(QKeyEvent *event);
        ~Ticket();

    private:
        Ui::Ticket *ui;
        QString m_strPresentDb_moduleId,m_strTic_Id,m_strticPrice,prnret;
        bool SaveData();
        bool PrintData();
        QTimer *t;


    private slots:
        void on_lineEdit_tic_no_returnPressed();
        void on_lineEdit_tic_qty_returnPressed();
        void on_pushButton_prnt_clicked();
        void on_pushButton_cancel_clicked();
        void data_status();
};

#endif // TICKET_H
