//#include "threadclass.h"
//#include <globalclass.h>
//#include "cmysqldatabase.h"

#include "global.h"
#include <QtSql/QSqlQuery>
#include <QProcess>
#include <QVariantList>
#include <QString>

using namespace Global;

#define DB_MACHINE_ID	QString(gqstrMachineId)

ThreadClass::ThreadClass(QObject *parent) :
    QThread(parent)
{
    LastError = false;
    gprsFlag = false;
    thredstatusflag =false;
    if(!Thrd_flag)
    {
        if(!g_ccmainObj->isGprs())
        {
            gErrorstr = g_ccmainObj->lastError();
            gprsFlag = true;
            return;
        }
        if(!g_ccmainObj->isEthernet())
        {
            gErrorstr = g_ccmainObj->lastError();
            gprsFlag = true;
            return;
        }
    }

}

void ThreadClass::run()
{
    qDebug()<<"Inside ThreadClass";

    QSqlQuery query;
    Thrd_flag = true;
    nsize_bill_info =0,nticket_bill_no = 0;
    while(Thrd_flag)
    {
         qDebug()<<"\r Enter into thread1111";
        if(gSqldatabase->SelectQuery("select count(ticket_unique_no) from ticket_transaction where UPLOAD_FLAG = 0",query))
        {
        //    qDebug()<<"\r Enter into thread";
            if(query.next())
            {
                qDebug()<<"\r local count"<<query.value(0).toInt();
                if(query.value(0).toInt() > 0 )
                {
                    query.clear();
                    if(gSqldatabase->SelectQuery("select max(ticket_unique_no) from ticket_transaction where UPLOAD_FLAG= 0", query))
                    {
                        if(query.next())
                        {
                            nsize_bill_info = query.value(0).toInt();                            
                        }
                        query.clear();
                    }
                    query.clear();
                    if(g_ccmainObj->isGprs() || g_ccmainObj->isEthernet())
                    {
                        if(gmysqldatabase->OpenMySqlConnection(presentDbid))
                        {
                            if(uploadData())
                                qDebug()<<"\r upload success";
                                gmysqldatabase->CloseConnectionMysql();
                        }
                        else
                        {
                            qDebug()<<"\r MYSQL OPEN FAIL";
                        }
                    }
                    else
                    {
                        gErrorstr = g_ccmainObj->lastError();
                        gthreadstatus = gErrorstr ;
                        qDebug()<<"\r GPRS FAIL";
                        emit thread_status(gthreadstatus);
                        gprsFlag = true;
                        return;

                    }
                }
                else
                {
                    qDebug()<<"\r No data available";
                    gthreadstatus ="\r No data available";
                    emit thread_status(gthreadstatus);
                }
            }
            else
            {

            }
        }
        sleep(5);
    }
}



bool ThreadClass::uploadData()
{
    qDebug()<<"Inside Upload Data";
    QSqlQuery qry,query1;
    QSqlQuery mysql_qry(gmysqldatabase->sqldatabaseMysqlObj);
    if(g_ccmainObj->isGprs() || g_ccmainObj->isEthernet())
    {
        if(gmysqldatabase->sqldatabaseMysqlObj.transaction())
        {
            qDebug()<<"\r is transcation start";

            if(gSqldatabase->SelectQuery("select ticket_unique_no,ticket_id,ticket_id_no,ticket_category_id,ticket_qty,ticket_user_name,ticket_machine_id,ticket_trans_no,ticket_trans_date,ticket_price,ticket_amt,ticket_trans_time  from ticket_transaction  where UPLOAD_FLAG= 0 and ticket_unique_no <= '"+QString::number(nsize_bill_info)+"'",qry))
            {

                    QString strqry;
                    strqry = "insert into ticket_transaction (ticket_bill_id,ticket_id,ticket_id_no,ticket_category_id,ticket_qty,ticket_user_name,ticket_machine_id,ticket_trans_no,ticket_trans_date,ticket_price,ticket_amt,ticket_trans_time) values (?,?,?,?,?,?,?,?,?,?,?,?)";
                    if(mysql_qry.prepare(strqry))
                    {
                        qDebug()<<"\r mysql success mysql success mysql success mysql success";
                    }
                    else
                    {
                        qDebug()<<"\r mysqlfail mysqlfail mysqlfail mysqlfail mysqlfail mysqlfail"<<mysql_qry.lastError();
                        return false;
                    }
                    while(qry.next())
                    {
                        qDebug()<<"\r mysqlcount";
                        mysql_qry.addBindValue(qry.value(0).toString());
                        mysql_qry.addBindValue(qry.value(1).toString());
                        mysql_qry.addBindValue(qry.value(2).toString());
                        mysql_qry.addBindValue(qry.value(3).toString());
                        mysql_qry.addBindValue(qry.value(4).toString());
                        mysql_qry.addBindValue(qry.value(5).toString());
                        mysql_qry.addBindValue(qry.value(6).toString());
                        mysql_qry.addBindValue(qry.value(7).toString());
                        mysql_qry.addBindValue(qry.value(8).toString());
                        mysql_qry.addBindValue(qry.value(9).toString());
                        mysql_qry.addBindValue(qry.value(10).toString());
                        mysql_qry.addBindValue(qry.value(11).toString());
                        if(!mysql_qry.exec())
                        {
                            gErrorstr = "Error while inserting data";
                            qDebug()<<""<<"\r Error while inserting data"<<mysql_qry.lastError();
                            //gthreadstatus = gErrorstr ;
                            gthreadstatus = gErrorstr ;
                            emit thread_status(gthreadstatus);
                            LastError = true;
                            return false;
                        }
                    }
                    //instead of the below command to insert data kindly follow the above method
//                    if(!mysql_qry->executeQuery("insert into ticket_transaction (ticket_bill_id,ticket_id,ticket_id_no,ticket_category_id,ticket_qty,ticket_user_name,ticket_machine_id,ticket_trans_no,ticket_trans_date,ticket_price,ticket_amt,ticket_trans_time) values ('"+qry.value(0).toString()+"','"+qry.value(1).toString()+"','"+qry.value(2).toString()+"','"+qry.value(3).toString()+"','"+qry.value(4).toString()+"','"+qry.value(5).toString()+"','"+qry.value(6).toString()+"','"+qry.value(7).toString()+"','"+qry.value(8).toString()+"','"+qry.value(9).toString()+"','"+qry.value(10).toString()+"','"+qry.value(11).toString()+"')"))
//                    {
//                        gErrorstr = "Error while inserting data";
                      //  qDebug()<<""<<gErrorstr;
//                        gthreadstatus = gErrorstr ;
//                        emit thread_status(gthreadstatus);
//                        LastError = true;
//                    }
//                    else
//                    {
                        if(gmysqldatabase->sqldatabaseMysqlObj.commit())
                        {
                            qDebug()<<"\r Mysql commited successfully";
                            if(gmysqldatabase->SelectQueryMysql("SELECT max(ticket_bill_id) FROM ticket_transaction where ticket_machine_id ='"+MachineID+"'",query1))
                            {

                                if(query1.next())
                                {
                                        nticket_bill_no = query1.value(0).toInt();
                                        if(gSqldatabase->ExecuteCommand("UPDATE ticket_transaction SET UPLOAD_FLAG = 1 WHERE ticket_machine_id = '"+MachineID+"'and ticket_unique_no <='"+QString::number(nticket_bill_no)+"'"))
                                        {
                                            gthreadstatus =" uploading data to server";
                                            qDebug()<<"\r uploading data to server"<<nticket_bill_no;
                                            emit thread_status(gthreadstatus);
                                            query1.clear();
                                            return true;
                                        }
                                }
                            }

                        }
                        else
                        {
                            qDebug()<<"\r MYsql commit fail";
                            gmysqldatabase->sqldatabaseMysqlObj.rollback();
                            query1.clear();
                            return false;
                        }
                    }
//                }
                qry.clear();
            }
            else
            {
                gErrorstr = "Error while selecting data ";
                qDebug()<<"\r Error while selecting data";
                gthreadstatus = gErrorstr ;
                emit thread_status(gthreadstatus);
                LastError = true;
                qry.clear();
                return false;
            }
        }
        else
        {
          //  qDebug()<<"\r MYSQL TRANSCATION FAIL";
            gmysqldatabase->sqldatabaseMysqlObj.rollback();
        }
    }
//}
void ThreadClass::stop_Thread()
{
    if (isRunning())
    {
        Thrd_flag = false;
        wait(2000);
        msleep(50);
    }
    return;
}


