/********************************************************************************
** Form generated from reading UI file 'totalamt.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOTALAMT_H
#define UI_TOTALAMT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Totalamt
{
public:
    QLabel *label_dt_caption;
    QLabel *label_caption;
    QLabel *label_amt;
    QPushButton *pushButton_exit;

    void setupUi(QDialog *Totalamt)
    {
        if (Totalamt->objectName().isEmpty())
            Totalamt->setObjectName(QString::fromUtf8("Totalamt"));
        Totalamt->resize(320, 220);
        Totalamt->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_dt_caption = new QLabel(Totalamt);
        label_dt_caption->setObjectName(QString::fromUtf8("label_dt_caption"));
        label_dt_caption->setGeometry(QRect(5, 20, 310, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Sans Serif"));
        font.setPointSize(22);
        font.setBold(true);
        font.setWeight(75);
        label_dt_caption->setFont(font);
        label_dt_caption->setAlignment(Qt::AlignCenter);
        label_caption = new QLabel(Totalamt);
        label_caption->setObjectName(QString::fromUtf8("label_caption"));
        label_caption->setGeometry(QRect(5, 70, 310, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Bamini"));
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        label_caption->setFont(font1);
        label_caption->setAlignment(Qt::AlignCenter);
        label_amt = new QLabel(Totalamt);
        label_amt->setObjectName(QString::fromUtf8("label_amt"));
        label_amt->setGeometry(QRect(4, 137, 313, 61));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Serif"));
        font2.setPointSize(27);
        font2.setBold(true);
        font2.setWeight(75);
        label_amt->setFont(font2);
        label_amt->setAlignment(Qt::AlignCenter);
        pushButton_exit = new QPushButton(Totalamt);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(220, 189, 93, 27));

        retranslateUi(Totalamt);

        QMetaObject::connectSlotsByName(Totalamt);
    } // setupUi

    void retranslateUi(QDialog *Totalamt)
    {
        Totalamt->setWindowTitle(QApplication::translate("Totalamt", "Dialog", 0, QApplication::UnicodeUTF8));
        label_dt_caption->setText(QString());
        label_caption->setText(QApplication::translate("Totalamt", ",d;iwa ifapUg;G \n"
" njhif", 0, QApplication::UnicodeUTF8));
        label_amt->setText(QApplication::translate("Totalamt", "999999999.99", 0, QApplication::UnicodeUTF8));
        pushButton_exit->setText(QApplication::translate("Totalamt", "Exit", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Totalamt: public Ui_Totalamt {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOTALAMT_H
