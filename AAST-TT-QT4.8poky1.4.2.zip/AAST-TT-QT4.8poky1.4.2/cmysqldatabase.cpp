//#include "cmysqldatabase.h"
#include <QMessageBox>
#include <QDebug>
//#include <globalclass.h>
#include "global.h"
#include <QSqlQuery>
using namespace  Global;

//****************Remote DB Connection*****************
#define DB_HOST_MYS	"132.148.158.149"
#define DB_USER_MYS "qglasewi_ttmachu"
#define DB_PASSWD_MYS "g)pU&B~+kwwE"
//****************Remote DB Connection*****************

//****************Local WW Server DB Connection*****************
//#define DB_HOST_MYS "192.168.1.4"
//#define DB_USER_MYS "root"
//#define DB_PASSWD_MYS ""
//****************Local WW Server DB Connection*****************

//****************Local DB Connection ASRST*****************
//#define DB_HOST_MYS	"192.168.2.10"
//#define DB_USER_MYS "root"
//#define DB_PASSWD_MYS "asrstMyPw03D2014"
//****************Local DB Connection ASRST*****************

//#define DB_HOST_MYS	"59.90.148.96"  //srirangam remote server 59.90.148.96
//#define DB_PASSWD_MYS   "asrstMyPw03D2014"
//#define DB_HOST_MYS_GPRS="59.90.148.96";
//#define DB_HOST_MYS	"192.168.1.4"
//#define DB_USER_MYS     "root"
//#define DB_PASSWD_MYS   ""
//#define DB_PASSWD_MYS_GPRS   "asrstMyPw03D2014"

#define DB_DBNAME_MYS   "automate_company"
#define DB_PORT_MYS     "3306"
//#define DB_DRIVER_MYS   "QMYSQL3"
#define DB_DRIVER_MYS   "QMYSQL"
#define DB_MACHINE_ID	QString(gqstrMachineId)

CMySqlDataBase::CMySqlDataBase()
{
    sqldatabaseMysqlObj = QSqlDatabase::addDatabase(DB_DRIVER_MYS,"mysql");
   // sqldatabaseMysqlObj = QSqlDatabase::addDatabase(DB_DRIVER_MYS);
}

bool CMySqlDataBase::OpenMySqlConnection(QString DBName)
{
    try
    {
        sqldatabaseMysqlObj.setHostName(DB_HOST_MYS);
        sqldatabaseMysqlObj.setUserName(DB_USER_MYS);
        sqldatabaseMysqlObj.setPassword(DB_PASSWD_MYS);
        sqldatabaseMysqlObj.setDatabaseName(DBName);
        sqldatabaseMysqlObj.setPort(QString(DB_PORT_MYS).toInt());

    //  sqldatabaseMysqlObj = QSqlDatabase::addDatabase(DB_DRIVER_MYS);
    //  sqldatabaseMysqlObj.setDatabaseName(DBName);
    //  sqldatabaseMysqlObj.setUserName(DB_USER_MYS);
    //  sqldatabaseMysqlObj.setPassword(DB_PASSWD_MYS);
    //  sqldatabaseMysqlObj.setHostName(DB_HOST_MYS);
    //  if(g_ccmainObj->isGprs())
    //    sqldatabaseMysqlObj.setHostName("59.90.148.96");
    //  else if(g_ccmainObj->isEthernet())
    //    sqldatabaseMysqlObj.setHostName("192.168.1.4");


        sqldatabaseMysqlObj.setPort(QString(DB_PORT_MYS).toInt());
        if(!sqldatabaseMysqlObj.open())
        {
            //            QMessageBox::critical(0,"Error","Cannot open database:" +sqldatabaseMysqlObj.lastError().text());
            gErrorstr = "Cannot open MySQL1 database:" +sqldatabaseMysqlObj.lastError().text();
            gthreadstatus = "Mysql connection Failed";
            return false;
        }
        return true;
    }
    catch(...)
    {
        //        QMessageBox::critical(0,"Error", "Can't open database:"
        //                              + sqldatabaseMysqlObj.lastError().text());
        gErrorstr = "Cannot open MySQL2 database:" +sqldatabaseMysqlObj.lastError().text();
        gthreadstatus = "Mysql connection Failed";
        return false;
    }
}

bool CMySqlDataBase::SelectQueryMysql(const QString &str, QSqlQuery &query)
{
    QSqlQuery mysqlquery(sqldatabaseMysqlObj);
    if(sqldatabaseMysqlObj.isOpen())
    {
        if(!mysqlquery.exec(str))
        {            
            gErrorstr = "select query  "+mysqlquery.lastError().text();
            return false;
        }
    }
    else
    {
        gErrorstr = "Database not open in select";
        return false;
    }
    query = mysqlquery;
    return true;
}
//int CMySqlDataBase::Size(QSqlQuery query)
//{
//    int size1 = 0;
//    while(query.next())
//    {
//        size1++;
//    }
//    query.clear();
//    return size1;
//}
bool CMySqlDataBase::executeQuery(QString strquery)
{
    QSqlQuery query(sqldatabaseMysqlObj);
//    qDebug()<<"\r"<<strquery;
    if(sqldatabaseMysqlObj.isOpen())
    {
        if(!query.exec(strquery))
        {
            gErrorstr = "execute query  "+query.lastError().text();
            return false;
        }
        return true;
    }
    else
    {
        gErrorstr = "Database not open in execute";
        return false;
    }
}

void CMySqlDataBase::CloseConnectionMysql()
{
    if(sqldatabaseMysqlObj.isOpen())
    {
        sqldatabaseMysqlObj.close();
    }
}

CMySqlDataBase::~CMySqlDataBase()
{
    CloseConnectionMysql();
    QSqlDatabase::removeDatabase(DB_DRIVER_MYS); /* remove the database driver */
}









