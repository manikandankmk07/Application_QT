/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QLabel *label_2;
    QLineEdit *lineEdit_PW;
    QPushButton *pushButton_cancel;
    QLineEdit *lineEdit_UN;
    QPushButton *pushButton_login;
    QLabel *label;
    QLabel *label_3;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QString::fromUtf8("Login"));
        Login->setWindowModality(Qt::NonModal);
        Login->resize(320, 230);
        Login->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_2 = new QLabel(Login);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(24, 130, 106, 17));
        QFont font;
        font.setFamily(QString::fromUtf8("Sans Serif"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        label_2->setFont(font);
        lineEdit_PW = new QLineEdit(Login);
        lineEdit_PW->setObjectName(QString::fromUtf8("lineEdit_PW"));
        lineEdit_PW->setGeometry(QRect(137, 123, 164, 34));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        font1.setPointSize(14);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(9);
        lineEdit_PW->setFont(font1);
        lineEdit_PW->setStyleSheet(QString::fromUtf8("font: 75 14pt \"Sans Serif\";\n"
"color: rgb(85, 0, 127);"));
        lineEdit_PW->setInputMethodHints(Qt::ImhHiddenText|Qt::ImhNoAutoUppercase|Qt::ImhNoPredictiveText|Qt::ImhPreferNumbers);
        lineEdit_PW->setMaxLength(4);
        lineEdit_PW->setEchoMode(QLineEdit::Password);
        lineEdit_PW->setCursorPosition(0);
        lineEdit_PW->setReadOnly(false);
        pushButton_cancel = new QPushButton(Login);
        pushButton_cancel->setObjectName(QString::fromUtf8("pushButton_cancel"));
        pushButton_cancel->setGeometry(QRect(185, 177, 93, 34));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Sans Serif"));
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton_cancel->setFont(font2);
        pushButton_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
"selection-color: rgb(0, 0, 255);"));
        lineEdit_UN = new QLineEdit(Login);
        lineEdit_UN->setObjectName(QString::fromUtf8("lineEdit_UN"));
        lineEdit_UN->setGeometry(QRect(137, 70, 164, 34));
        lineEdit_UN->setFont(font1);
        lineEdit_UN->setAutoFillBackground(false);
        lineEdit_UN->setStyleSheet(QString::fromUtf8("font: 75 14pt \"Sans Serif\";\n"
"color: rgb(85, 0, 127);"));
        lineEdit_UN->setLocale(QLocale(QLocale::English, QLocale::India));
        lineEdit_UN->setMaxLength(4);
        lineEdit_UN->setFrame(true);
        pushButton_login = new QPushButton(Login);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));
        pushButton_login->setGeometry(QRect(45, 177, 93, 34));
        pushButton_login->setFont(font2);
        pushButton_login->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
"selection-background-color: rgb(0, 0, 127);"));
        label = new QLabel(Login);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(24, 79, 106, 17));
        label->setFont(font);
        label_3 = new QLabel(Login);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(130, 23, 62, 22));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Times New Roman"));
        font3.setPointSize(14);
        font3.setBold(true);
        font3.setWeight(75);
        label_3->setFont(font3);
        QWidget::setTabOrder(lineEdit_UN, lineEdit_PW);
        QWidget::setTabOrder(lineEdit_PW, pushButton_login);
        QWidget::setTabOrder(pushButton_login, pushButton_cancel);

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QApplication::translate("Login", "Dialog", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Login", "Password", 0, QApplication::UnicodeUTF8));
        lineEdit_PW->setInputMask(QString());
        lineEdit_PW->setText(QString());
        pushButton_cancel->setText(QApplication::translate("Login", "Cancel", 0, QApplication::UnicodeUTF8));
        lineEdit_UN->setInputMask(QString());
        pushButton_login->setText(QApplication::translate("Login", "Ok", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Login", "User Name", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Login", "Login ", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
