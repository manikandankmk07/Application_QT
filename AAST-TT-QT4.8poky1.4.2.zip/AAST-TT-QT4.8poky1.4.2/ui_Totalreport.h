/********************************************************************************
** Form generated from reading UI file 'Totalreport.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOTALREPORT_H
#define UI_TOTALREPORT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Totalreport
{
public:
    QLabel *label_date;
    QLabel *label_user;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_print;

    void setupUi(QDialog *Totalreport)
    {
        if (Totalreport->objectName().isEmpty())
            Totalreport->setObjectName(QString::fromUtf8("Totalreport"));
        Totalreport->resize(320, 220);
        Totalreport->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_date = new QLabel(Totalreport);
        label_date->setObjectName(QString::fromUtf8("label_date"));
        label_date->setGeometry(QRect(80, 50, 141, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Sans Serif"));
        font.setPointSize(21);
        label_date->setFont(font);
        label_user = new QLabel(Totalreport);
        label_user->setObjectName(QString::fromUtf8("label_user"));
        label_user->setGeometry(QRect(80, 100, 141, 31));
        label_user->setFont(font);
        pushButton_exit = new QPushButton(Totalreport);
        pushButton_exit->setObjectName(QString::fromUtf8("pushButton_exit"));
        pushButton_exit->setGeometry(QRect(210, 180, 93, 34));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton_exit->setFont(font1);
        pushButton_exit->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
"selection-color: rgb(0, 0, 255);"));
        pushButton_print = new QPushButton(Totalreport);
        pushButton_print->setObjectName(QString::fromUtf8("pushButton_print"));
        pushButton_print->setGeometry(QRect(90, 180, 93, 34));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton_print->setFont(font2);
        pushButton_print->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));

        retranslateUi(Totalreport);

        QMetaObject::connectSlotsByName(Totalreport);
    } // setupUi

    void retranslateUi(QDialog *Totalreport)
    {
        Totalreport->setWindowTitle(QApplication::translate("Totalreport", "Dialog", 0, QApplication::UnicodeUTF8));
        label_date->setText(QString());
        label_user->setText(QString());
        pushButton_exit->setText(QApplication::translate("Totalreport", "Cancel", 0, QApplication::UnicodeUTF8));
        pushButton_print->setText(QApplication::translate("Totalreport", "Print", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Totalreport: public Ui_Totalreport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOTALREPORT_H
