#include "cdatabase.h"
#include "global.h"
#include <QMessageBox>
#include <QDebug>
#include <QString>
#include<QDir>

using namespace Global;

/*****************************************************************************
                                MACROS
******************************************************************************/
#define DB_DRIVER ("QSQLITE") /** The Database Driver name. */

CDatabase::CDatabase()
{
    /*add the databasedriver for sqlite*/
    sqldatabaseSqlObj = QSqlDatabase::addDatabase(DB_DRIVER);
   // QMessageBox::critical(0,"Info","Local Database Driver Added");
   // QMessageBox::critical(0,"Info",DB_DRIVER);
}

bool CDatabase::OpenConnection(QString DB_name)
{
    try
    {
        sqldatabaseSqlObj.setDatabaseName(DB_name);

       // QMessageBox::critical(0,"Info","Local Database setted");
       // QMessageBox::critical(0,"Info",DB_name);


        /* open the database and check whether opened or not */
        if(!sqldatabaseSqlObj.open())
        {
            qDebug()<<"DB Connection status failed==========>>";
            QMessageBox::critical(0,"Error","Cannot open Local Database:"+sqldatabaseSqlObj.lastError().text());
            return false;
        }

        sqldatabaseSqlObj = QSqlDatabase::database();
        if(!CreateDefaultTables())
        {
            QMessageBox::critical(0,"Error","Error in CreateDefaultTables");
            CreateDefaultTables();
            //return false;
        }

        return true;
    }
    catch(...)
    {
        qDebug()<<"Connection failed ====>>>";
        return false;
    }
}

bool CDatabase::ExecuteCommand(const QString &query)
{
    QSqlQuery qry;
    if(sqldatabaseSqlObj.isOpen())
    {
        if(!qry.exec(query))
        {
            //QMessageBox::critical(0,"Error:","Error:"+qry.lastError().text());
            gErrorstr = "local DB Error in execute :"+qry.lastError().text();
            qDebug()<<"\r Error"<<gErrorstr;
            qry.clear();
            return false;
        }
        qry.clear();
        return true;
    }
    else
    {

        gErrorstr = "local DB not open";
        return false;
    }
}

bool CDatabase::CreateDefaultTables()
{
    if(!ExecuteCommand("CREATE TABLE IF NOT EXISTS `present_ticket_db` (`db_id` varchar(30) DEFAULT NULL)"))
    {
        qDebug()<<"fail to create table 1";
        return false;
    }
    if(!ExecuteCommand("CREATE TABLE if not exists `current_booking_master`(`cb_ticket_id` varchar(30) DEFAULT NULL,`cb_ticket_category_id` varchar(30) DEFAULT NULL,`cb_ticket_category_name` varchar(60) DEFAULT NULL,`cb_ticket_name` varchar(75) DEFAULT NULL,`cb_ticket_uni_name` varchar(200) DEFAULT NULL,`cb_ticket_eng_name` varchar(100) DEFAULT NULL,`cb_ticket_amount` double(13,2) DEFAULT NULL,`cb_ticket_print_type` tinyint(1) DEFAULT '0',`cb_share_exp` double(13,2) DEFAULT NULL,`cb_share_temple` double(13,2) DEFAULT NULL,`cb_share_archagar` double(13,2) DEFAULT NULL,`cb_share_barber` double(13,2) DEFAULT NULL,`cb_share_total` double(13,2) DEFAULT '0.00',`cb_ticket_category_idno` int(3) DEFAULT '0',`cb_ticket_idno` int(3) DEFAULT '0',`cb_ticket_status` tinyint(1) DEFAULT '1',`deleted` tinyint(1) DEFAULT '0',`ticket_id` int(3) NOT NULL,`cb_copies` int(3) DEFAULT '1' )"))
    {
        qDebug()<<"fail to create table 2";
        return false;
    }
    if(!ExecuteCommand("CREATE TABLE  if not exists `ticket_transaction` (`ticket_unique_no` INTEGER PRIMARY KEY AUTOINCREMENT,`ticket_id` int(5) DEFAULT NULL,`ticket_id_no` varchar(30) DEFAULT NULL,`ticket_category_id` varchar(30) DEFAULT NULL,`ticket_qty` int(5) DEFAULT NULL,`ticket_user_name` varchar(30) DEFAULT NULL,`ticket_machine_id` varchar(30) DEFAULT NULL,`ticket_trans_no` int(7) DEFAULT NULL,`ticket_trans_date` date DEFAULT NULL,`ticket_price` double(7,2) DEFAULT NULL,`ticket_amt` double(13,2) DEFAULT NULL,`deleted` tinyint(1) DEFAULT '0',`UPLOAD_FLAG` int(2) NOT NULL,`ticket_trans_time` varchar(8) DEFAULT NULL)"))
    {
        qDebug()<<"fail to create table 3";
        return false;
    }
    if(!ExecuteCommand("create index if not exists  ticketindex on ticket_transaction (ticket_id_no,ticket_user_name,ticket_trans_date)"))
    {
        qDebug()<<"fail to create index 4";
        return false;
    }
    if(!ExecuteCommand("CREATE INDEX if not exists ticketprintindex on ticket_transaction (ticket_trans_no,ticket_id)"))
    {
        qDebug()<<"fail to create index 5";
        return false;
    }
    if(!ExecuteCommand("CREATE TABLE  if not exists `ticket_user_master` (`ttm_user_id` varchar(20),`ttm_user_name` varchar(20),`ttm_userid` varchar(10),`ttm_user_passwd` int(4),`ttm_modules_enable_id` blob,`ttm_last_updated_dt` date,`ttm_maintemple` tinyint(1),`ttm_subtemple` tinyint(1),`deleted` tinyint(1))"))
    {
        qDebug()<<"fail to create table 6";
        return false;
    }
    return true;
}
bool CDatabase::ExecuteQuery(QSqlQuery &sqlQuery)
{
#if DEBUG
    qDebug()<<"\r query : "<<sqlQuery.lastQuery();
#endif
    if(sqldatabaseSqlObj.isOpen()) /* check the database connection is open or not */
    {
        /* execute the query string and give the the result via resQuery */
        if(!sqlQuery.exec())
        {
            qDebug()<<"\r unable to execute the query";
            return false;
        }
        return true;
    }
    else
    {
        qDebug()<<"\r connection not open in executequery";
        return false;
    }
}

int CDatabase::size(QSqlQuery query)
{
    int size1=0;
    /* count the no of records in the result */
    while(query.next())
    {
        size1++;
    }
    query.clear();
    return size1;
}
bool CDatabase::SelectQuery(const QString &query, QSqlQuery &qry)
{
    if(sqldatabaseSqlObj.isOpen())
    {
//        qDebug()<<query;
        if(!qry.exec(query))
        {
//            QMessageBox::critical(0,"Error","select query "+qry.lastError().text());
            gErrorstr = "local DB Erro in select :"+qry.lastError().text();
            return false;
        }
        qry.size();
    }
    else
    {
        sqldatabaseSqlObj.open();
//        QMessageBox::critical(0,"Error","Database not open");
         gErrorstr = "local DB not open";
        return false;
    }
    return true;
}

//int CDatabase::TableSize(QSqlQuery query)
//{
//    int nsize = 0;
//    while(query.next())
//    {
//        nsize++;
//    }
//    query.clear();
//    return nsize;
//}

void CDatabase::CloseConnection()
{
    if(sqldatabaseSqlObj.isOpen())
    {
        sqldatabaseSqlObj.close();
    }
}
CDatabase::~CDatabase()
{
    CloseConnection();
    QSqlDatabase::removeDatabase(DB_DRIVER); /* remove the database driver */
}

