/********************************************************************************
** Form generated from reading UI file 'modules.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODULES_H
#define UI_MODULES_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Modules
{
public:
    QPushButton *pushButton_1;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QLabel *label;
    QLabel *label_2;
    QGroupBox *groupBox;
    QButtonGroup *buttonGroup;

    void setupUi(QDialog *Modules)
    {
        if (Modules->objectName().isEmpty())
            Modules->setObjectName(QString::fromUtf8("Modules"));
        Modules->resize(320, 220);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(0, 255, 0, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        QBrush brush2(QColor(60, 59, 55, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        QBrush brush3(QColor(150, 147, 140, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        Modules->setPalette(palette);
        Modules->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        pushButton_1 = new QPushButton(Modules);
        buttonGroup = new QButtonGroup(Modules);
        buttonGroup->setObjectName(QString::fromUtf8("buttonGroup"));
        buttonGroup->addButton(pushButton_1);
        pushButton_1->setObjectName(QString::fromUtf8("pushButton_1"));
        pushButton_1->setGeometry(QRect(7, 76, 151, 34));
        QFont font;
        font.setFamily(QString::fromUtf8("Bamini"));
        font.setPointSize(14);
        font.setBold(false);
        font.setWeight(50);
        pushButton_1->setFont(font);
        pushButton_1->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        pushButton_2 = new QPushButton(Modules);
        buttonGroup->addButton(pushButton_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(160, 76, 151, 34));
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        pushButton_3 = new QPushButton(Modules);
        buttonGroup->addButton(pushButton_3);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(7, 125, 151, 40));
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        pushButton_4 = new QPushButton(Modules);
        buttonGroup->addButton(pushButton_4);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(160, 125, 151, 40));
        pushButton_4->setFont(font);
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        pushButton_5 = new QPushButton(Modules);
        buttonGroup->addButton(pushButton_5);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(7, 178, 151, 34));
        pushButton_5->setFont(font);
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        pushButton_6 = new QPushButton(Modules);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(160, 178, 151, 34));
        pushButton_6->setFont(font);
        pushButton_6->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        label = new QLabel(Modules);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(130, 16, 71, 20));
        label_2 = new QLabel(Modules);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(11, 35, 301, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        font1.setPointSize(13);
        font1.setBold(true);
        font1.setWeight(75);
        label_2->setFont(font1);
        groupBox = new QGroupBox(Modules);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(0, 0, 320, 220));
        groupBox->raise();
        pushButton_1->raise();
        pushButton_2->raise();
        pushButton_3->raise();
        pushButton_4->raise();
        pushButton_5->raise();
        pushButton_6->raise();
        label->raise();
        label_2->raise();
        QWidget::setTabOrder(pushButton_1, pushButton_2);
        QWidget::setTabOrder(pushButton_2, pushButton_3);
        QWidget::setTabOrder(pushButton_3, pushButton_4);
        QWidget::setTabOrder(pushButton_4, pushButton_5);
        QWidget::setTabOrder(pushButton_5, pushButton_6);

        retranslateUi(Modules);

        QMetaObject::connectSlotsByName(Modules);
    } // setupUi

    void retranslateUi(QDialog *Modules)
    {
        Modules->setWindowTitle(QApplication::translate("Modules", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton_1->setText(QApplication::translate("Modules", "ngUkhs; rd;djp", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Modules", "jhahu; rd;djp", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("Modules", "rf;fuj;jho;thu;", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("Modules", ",ju tif", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("Modules", "hpg;Nghu;l;", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("Modules", "njhif", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        label_2->setText(QApplication::translate("Modules", "\340\256\270\340\257\215\340\256\260\340\257\200 \340\256\260\340\256\231\340\257\215\340\256\225\340\256\250\340\256\276\340\256\244\340\256\260\340\257\215 \340\256\232\340\257\201\340\256\265\340\256\276\340\256\256\340\256\277 \340\256\244\340\256\277\340\256\260\340\257\201\340\256\225\340\257\215\340\256\225\340\257\213\340\256\265\340\256\277\340\256\262\340\257\215", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QString());
    } // retranslateUi

};

namespace Ui {
    class Modules: public Ui_Modules {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODULES_H
