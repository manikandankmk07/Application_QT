#ifndef CMYSQLDATABASE_H
#define CMYSQLDATABASE_H

#include <QSqlDatabase>
#include<QSqlQuery>
#include<QSqlDriver>
#include<QSqlError>

class CMySqlDataBase
{
public:
    CMySqlDataBase();
    QSqlDatabase sqldatabaseMysqlObj;
    ~CMySqlDataBase();

    QString drive, db_name;
    bool OpenMySqlConnection(QString DBName);
    bool SelectQueryMysql(const QString &str, QSqlQuery &query);
    bool executeQuery(QString strquery);
    void CloseConnectionMysql();
//    int Size(QSqlQuery query);
};

#endif // CMYSQLDATABASE_H
