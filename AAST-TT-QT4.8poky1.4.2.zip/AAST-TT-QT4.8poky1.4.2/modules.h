#ifndef MODULES_H
#define MODULES_H

#include "global.h"
#include <QDialog>
#include <QKeyEvent>


namespace Ui {
    class Modules;
}

class Modules : public QDialog
{
    Q_OBJECT

public:
    explicit Modules(QWidget *parent,QStringList module);
    void keyPressEvent(QKeyEvent *event);


    QStringList lst_line_data,lst_line_size,lst_is_bold,lst_is_italic,lst_font_family;
    enum PreView_Alignment
    {
        PreViewAlignment_LEFT ,      /**< Aligns with the left. */
        PreViewAlignment_CENTER ,    /**< Align with center. */
        PreViewAlignment_RIGHT       /**< Aligns with the right. */
    };

    void add_image_data(QString r_const_imageDATA,QString font_family,
                        int font_size, bool isBold, bool is_italic,
                        PreView_Alignment preview_Align = PreViewAlignment_LEFT);

    void creat_image_to_print();

    QImage i1;


    ~Modules();

private:
    Ui::Modules *ui;
    bool ReportPrint();

private slots:
    void on_pushButton_1_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();

};

#endif // MODULES_H
