#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "global.h"
#include <QFile>

using namespace Global;

#if(SDK75)
#define APP_DB "/home/root/ATTTTTicket.db"
#define DB_DBNAME_MYS "automate_company"
#include <chhc72xx.h>
#include <GlobalClass.h>
#include <device_menu.h>
using namespace Globalclass;
#endif

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //  gchh80xxObj =new CHHC80xx;

    //Chh_obj = new CHHC72xx;
#if(SDK75)
//    qDebug()<<"MainWindow ===>>>2";
//    MdiArea=new QMdiArea(this);
//    setCentralWidget(MdiArea);
//    MdiArea->setBackground(QBrush(Qt::white));
//    setWindowFlags(Qt::FramelessWindowHint);
//    g_ccmainObj = new CHHC72xx(MdiArea);
//    addToolBar(g_ccmainObj->serverMethod()->HHC80xxPanel());
//    addToolBarBreak(Qt::TopToolBarArea);

    MdiArea=new QMdiArea(this);
    setCentralWidget(MdiArea);
    MdiArea->setBackground(QBrush(Qt::white));
    setWindowFlags(Qt::FramelessWindowHint);
    qDebug()<<"MainWindow ===>>>3";
    g_ccmainObj = new CHHC72xx(MdiArea);
    qDebug()<<"MainWindow ===>>>4";
    addToolBar(g_ccmainObj->serverMethod()->HHC80xxPanel());
    qDebug()<<"MainWindow ===>>>5";
    addToolBarBreak(Qt::TopToolBarArea);

   // setParent(MdiArea,Qt::Dialog);

    sleep(1);
    qDebug()<<"GPRS:"<<g_ccmainObj->isGprs();
    qDebug()<<"EtherNet:"<<g_ccmainObj->isEthernet();

    MachineID.clear();
    MachineID=g_ccmainObj->machineId();

#endif

//    setWindowFlags(Qt::FramelessWindowHint);
//    setFocusPolicy(Qt::NoFocus);
//    setFixedSize(320,240);

    this->hide();

    gSqldatabase = new CDatabase();


    gmysqldatabase = new CMySqlDataBase();


    if(gSqldatabase->OpenConnection(APP_DB))
    {
        qDebug()<<"Connected Local DB================>>";
        qDebug()<<APP_DB;
    }
    else
        qDebug()<<"Failed ===============>>";

    if(gmysqldatabase->OpenMySqlConnection(DB_DBNAME_MYS))
    {
        qDebug()<<"Connected Mysql DB================>>";
        qDebug()<<DB_DBNAME_MYS;
    }
    else{
        qDebug()<<"Failed to connect Mysql Db================>>";
        qDebug()<<DB_DBNAME_MYS;
    }

    //    g_ccmainObj->initializeGSMModule();
    //    g_ccmainObj->enableGprs();

//#if(SDK75)
//    MachineID.clear();
//    MachineID=g_ccmainObj->machineId();
//    MachineID= gchh80xxObj->machineId();
//    MachineID = MachineID.remove(0,11);
//#endif

    qDebug()<<"Machine ID: "<<MachineID;
    //qDebug()<<g_ccmainObj;
    //>machineId();

    // g_ccmainObj->EnableGSMMessageBox(false);
    //    g_ccmainObj->EnablePRINTERModule(true);

    gprsfail_cnt = 0;
    dberror_cnt = 0;
    neterror_cnt = 0;

    t = new QTimer;
    t->setSingleShot(true);
    connect(t, SIGNAL(timeout()), this, SLOT(GPRS_Failed()));

    //    Login *widgetLogin=new Login(this);
    //    widgetLogin->setAttribute(Qt::WA_DeleteOnClose);
    //    widgetLogin->show();


    loginObj = new LoginClass();
    loginObj->call_login();
    loginObj->show();
    connect(loginObj ,SIGNAL(callthread()),this,SLOT(StartThread()));

    //    gSqldatabase = new CDatabase();
    //    if(gSqldatabase->OpenConnection(APP_DB))
    //    {
    //        qDebug()<<"Database Connected successfully ====>> ";
    //    }
    //    else
    //        qDebug()<<"Failed to connect";

}

void MainWindow::StartThread()
{
    th_upld = new ThreadClass;
    if(!th_upld->gprsFlag)
    {
        if(!th_upld->LastError)
        {
            connect(th_upld, SIGNAL(Thread_stopped(bool)), this, SLOT(Thread_terminated(bool)));
            connect(th_upld,SIGNAL(thread_status(QString)),this,SLOT(thread_Status(QString)));
            th_upld->start();
        }
    }
    else
    {
        if(th_upld->Errorstr.contains("SIM not inserted") || th_upld->Errorstr.contains("Gsm module commuication Error!"))
        {
            qDebug()<<"\r gprsflag false and gsm module no error";
            delete th_upld;
            QMessageBox::critical(0, "Upload", th_upld->Errorstr);
        }
        else
        {
            delete th_upld;
            gprsfail_cnt = 0;
            GPRS_Failed();
        }
    }
}
void MainWindow::thread_Status(QString threadstatus)
{
    gthreadstatus = threadstatus;
}

void MainWindow::Thread_terminated(bool netstatus)
{
    qDebug()<<"\rneterror count ..."+QString::number(neterror_cnt);

    if(th_upld->gprsFlag)
    {
        if(th_upld->LastError)
        {
            Errorlog(th_upld->Errorstr);
        }
        if(netstatus)
        {
            if(neterror_cnt == 1 || neterror_cnt == 2)
            {
                neterror_cnt = 0;
                GPRS_Failed();
                return;
            }
            else
            {
                qDebug()<<"\net error count 0";
                g_ccmainObj->disconnect();
                delete th_upld;
                neterror_cnt = 0;
                StartThread();
                neterror_cnt++;
            }

        }
        else
        {
            if(dberror_cnt == 0 || dberror_cnt == 2)
            {
                th_upld->start();
                dberror_cnt++;
                return;
            }
            else
            {
                dberror_cnt = 0;
                th_upld->start();
                dberror_cnt++;
            }
        }
    }

}

void MainWindow::GPRS_Failed()
{
    qDebug()<<"\rGPRSfailcount"<<gprsfail_cnt;
    if(gprsfail_cnt == 1 || gprsfail_cnt == 2)
    {
        qDebug()<<"\r network communication failed";
        if(g_ccmainObj->isGprs())
            g_ccmainObj->disableGprs();
        StartThread();
        return;
    }
    else
    {
        StartThread();
    }
    gprsfail_cnt++;
}
void MainWindow::Errorlog(QString errorStr)
{
    QFile f("/mnt/ATError_log");
    if(f.open(QIODevice::Append))
    {
        QTextStream *in = new QTextStream(&f);
        *in<<QDateTime::currentDateTime().toString("dd/MM/yyyy hh:mm:ss-:-")<<errorStr<< endl;
        delete in;
    }
    else
    {
        qDebug()<<"log file open error";
    }
    f.close();
}
MainWindow::~MainWindow()
{
    delete gSqldatabase;
    delete gmysqldatabase;
    delete g_ccmainObj;
}

