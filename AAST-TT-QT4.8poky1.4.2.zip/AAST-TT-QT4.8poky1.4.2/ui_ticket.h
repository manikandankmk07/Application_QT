/********************************************************************************
** Form generated from reading UI file 'ticket.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TICKET_H
#define UI_TICKET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Ticket
{
public:
    QGroupBox *groupBox;
    QLabel *label_6_tic_name;
    QLabel *label;
    QPushButton *pushButton_cancel;
    QLineEdit *lineEdit_tic_qty;
    QLabel *label_check;
    QPushButton *pushButton_prnt;
    QLabel *label_2;
    QLabel *labelTicket_status;
    QLabel *label_4_Rs;
    QLabel *label_5_amt;
    QLineEdit *lineEdit_tic_no;
    QLabel *label_3_mod_name;
    QLabel *label_3;

    void setupUi(QDialog *Ticket)
    {
        if (Ticket->objectName().isEmpty())
            Ticket->setObjectName(QString::fromUtf8("Ticket"));
        Ticket->resize(320, 200);
        Ticket->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        groupBox = new QGroupBox(Ticket);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(0, 0, 320, 210));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_6_tic_name = new QLabel(groupBox);
        label_6_tic_name->setObjectName(QString::fromUtf8("label_6_tic_name"));
        label_6_tic_name->setGeometry(QRect(0, 42, 313, 22));
        QFont font;
        font.setFamily(QString::fromUtf8("Bamini"));
        font.setPointSize(18);
        label_6_tic_name->setFont(font);
        label_6_tic_name->setAlignment(Qt::AlignCenter);
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(38, 68, 141, 22));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        pushButton_cancel = new QPushButton(groupBox);
        pushButton_cancel->setObjectName(QString::fromUtf8("pushButton_cancel"));
        pushButton_cancel->setGeometry(QRect(217, 165, 93, 34));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        pushButton_cancel->setFont(font2);
        pushButton_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
""));
        lineEdit_tic_qty = new QLineEdit(groupBox);
        lineEdit_tic_qty->setObjectName(QString::fromUtf8("lineEdit_tic_qty"));
        lineEdit_tic_qty->setGeometry(QRect(230, 95, 51, 31));
        QFont font3;
        font3.setPointSize(22);
        font3.setBold(true);
        font3.setWeight(75);
        lineEdit_tic_qty->setFont(font3);
        lineEdit_tic_qty->setMaxLength(1);
        label_check = new QLabel(groupBox);
        label_check->setObjectName(QString::fromUtf8("label_check"));
        label_check->setGeometry(QRect(0, 241, 100, 10));
        QFont font4;
        font4.setFamily(QString::fromUtf8("Courier 10 Pitch"));
        font4.setPointSize(18);
        label_check->setFont(font4);
        label_check->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        pushButton_prnt = new QPushButton(groupBox);
        pushButton_prnt->setObjectName(QString::fromUtf8("pushButton_prnt"));
        pushButton_prnt->setGeometry(QRect(117, 165, 93, 34));
        pushButton_prnt->setFont(font2);
        pushButton_prnt->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);"));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(38, 98, 187, 22));
        label_2->setFont(font1);
        labelTicket_status = new QLabel(groupBox);
        labelTicket_status->setObjectName(QString::fromUtf8("labelTicket_status"));
        labelTicket_status->setGeometry(QRect(0, 0, 313, 20));
        labelTicket_status->setAlignment(Qt::AlignCenter);
        label_4_Rs = new QLabel(groupBox);
        label_4_Rs->setObjectName(QString::fromUtf8("label_4_Rs"));
        label_4_Rs->setGeometry(QRect(37, 125, 71, 40));
        QFont font5;
        font5.setFamily(QString::fromUtf8("Sans Serif"));
        font5.setPointSize(36);
        label_4_Rs->setFont(font5);
        label_5_amt = new QLabel(groupBox);
        label_5_amt->setObjectName(QString::fromUtf8("label_5_amt"));
        label_5_amt->setGeometry(QRect(117, 129, 191, 36));
        QFont font6;
        font6.setFamily(QString::fromUtf8("Sans Serif"));
        font6.setPointSize(32);
        label_5_amt->setFont(font6);
        lineEdit_tic_no = new QLineEdit(groupBox);
        lineEdit_tic_no->setObjectName(QString::fromUtf8("lineEdit_tic_no"));
        lineEdit_tic_no->setGeometry(QRect(230, 63, 52, 30));
        lineEdit_tic_no->setFont(font3);
        lineEdit_tic_no->setMaxLength(3);
        label_3_mod_name = new QLabel(groupBox);
        label_3_mod_name->setObjectName(QString::fromUtf8("label_3_mod_name"));
        label_3_mod_name->setGeometry(QRect(0, 14, 313, 25));
        QFont font7;
        font7.setFamily(QString::fromUtf8("Bamini"));
        font7.setPointSize(20);
        font7.setBold(false);
        font7.setWeight(50);
        label_3_mod_name->setFont(font7);
        label_3_mod_name->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 70, 251, 71));
        QFont font8;
        font8.setFamily(QString::fromUtf8("DejaVu Sans Mono"));
        font8.setPointSize(14);
        label_3->setFont(font8);
        label_3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label_3->raise();
        label_6_tic_name->raise();
        label->raise();
        pushButton_cancel->raise();
        lineEdit_tic_qty->raise();
        label_check->raise();
        pushButton_prnt->raise();
        label_2->raise();
        labelTicket_status->raise();
        label_4_Rs->raise();
        label_5_amt->raise();
        lineEdit_tic_no->raise();
        label_3_mod_name->raise();

        retranslateUi(Ticket);

        QMetaObject::connectSlotsByName(Ticket);
    } // setupUi

    void retranslateUi(QDialog *Ticket)
    {
        Ticket->setWindowTitle(QApplication::translate("Ticket", "Dialog", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QString());
        label_6_tic_name->setText(QString());
        label->setText(QApplication::translate("Ticket", "Ticket No:", 0, QApplication::UnicodeUTF8));
        pushButton_cancel->setText(QApplication::translate("Ticket", "Cancel", 0, QApplication::UnicodeUTF8));
        label_check->setText(QApplication::translate("Ticket", "=>", 0, QApplication::UnicodeUTF8));
        pushButton_prnt->setText(QApplication::translate("Ticket", "Print", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Ticket", "No. of Tickets:", 0, QApplication::UnicodeUTF8));
        labelTicket_status->setText(QApplication::translate("Ticket", "Upload", 0, QApplication::UnicodeUTF8));
        label_4_Rs->setText(QApplication::translate("Ticket", "Rs.", 0, QApplication::UnicodeUTF8));
        label_5_amt->setText(QString());
        label_3_mod_name->setText(QString());
        label_3->setText(QApplication::translate("Ticket", "        PRINTING", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Ticket: public Ui_Ticket {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TICKET_H
