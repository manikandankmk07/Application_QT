//#include "templesel.h"
#include "ui_templesel.h"
//#include "modules.h"
//#include <login.h>
//#include <globalclass.h>
#include <QDebug>
#include <QKeyEvent>
//#include "subtemplesel.h"
//#include "globalclass.h"
#include "global.h"
//#include <CPrinter>

using namespace Global;

Templesel::Templesel(QWidget *parent,QStringList templesel) :
    QDialog(parent),
    ui(new Ui::Templesel)
{
    ui->setupUi(this);

//    #if(SDK75)
//        setParent(MdiArea,Qt::Dialog);
//    #endif

//    setParent(gmdiareaObj);
//    setWindowFlags(Qt::FramelessWindowHint);
//    setFocusPolicy(Qt::NoFocus);
//    setFixedSize(320,240);

    ui->pushButton_1->setFocus();
}
Templesel::~Templesel()
{
    delete ui;
}

void Templesel::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        this->close();
//        Login *log=new Login(this);
//        log->show();
        loginObj->call_login();
        loginObj->show();
    }
}
void Templesel::on_pushButton_1_clicked()
{
    MnmoduleId="1";
    this->hide();
    Modules *widgetModules=new Modules(this,modlist);
    widgetModules->show();
}
void Templesel::on_pushButton_2_clicked()
{
    MnmoduleId="2";
    this->hide();
    Subtemplesel *widgetSubtemplesel=new Subtemplesel(this,modlist);
    widgetSubtemplesel->show();
}
