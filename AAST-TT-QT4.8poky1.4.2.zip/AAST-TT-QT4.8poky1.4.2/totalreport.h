#ifndef TOTALREPORT_H
#define TOTALREPORT_H
#include "global.h"
#include <QDialog>
#include <QKeyEvent>

namespace Ui {
    class Totalreport;
}

class Totalreport : public QDialog
{
    Q_OBJECT

    public:
        explicit Totalreport(QWidget *parent);
    //,QString moduleId);

    //QString firstline,secndline;

    //QString moduleId;

    QStringList lst_line_data,lst_line_size,lst_is_bold,lst_is_italic,lst_font_family;
    enum PreView_Alignment
    {
        PreViewAlignment_LEFT ,      /**< Aligns with the left. */
        PreViewAlignment_CENTER ,    /**< Align with center. */
        PreViewAlignment_RIGHT       /**< Aligns with the right. */
    };

    void add_image_data(QString r_const_imageDATA,QString font_family,
                        int font_size, bool isBold, bool is_italic,
                        PreView_Alignment preview_Align = PreViewAlignment_LEFT);

    void creat_image_to_print();

    QImage i1;


        ~Totalreport();

    private:
        Ui::Totalreport *ui;
        bool ReportPrint();

    private slots:
        void on_pushButton_print_clicked();
        void on_pushButton_exit_clicked();

};





#endif // TOTALREPORT_H
