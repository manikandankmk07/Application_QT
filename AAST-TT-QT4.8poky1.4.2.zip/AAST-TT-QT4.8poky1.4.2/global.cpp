#include "global.h"

using namespace Global;

QMdiArea *Global::gmdiareaObj=0;
LoginClass *Global::loginObj=0;
QLabel *Global::glabelTitle =0;
CDatabase *Global::gSqldatabase = 0;
CMySqlDataBase *Global::gmysqldatabase = 0;

Ticket *Global::widgetTicket=0;
Totalamt *Global::widgetTotalamt=0;

//CHHC80xx * Global::gchh80xxObj=0;
QString Global::presentDbid="";
QStringList Global::modlist;
QString Global::UName="";
QString Global::MachineID="";
QString Global::TicketUniName="";
QString Global::TicketEngName="";
int Global::TicketCopies=1;
QString Global::usFullNm="";
QString Global::gErrorstr = "";
int Global::ticket_prnt=0;
QString Global::gthreadstatus = "";
QString Global::moduleId ="";
QString Global::MnmoduleId = "";

QString Global::ModuleName = "";
QString Global::TransDetails = "";
QString Global::TickettransNo = "";
QString Global::TickettransId = "";

QString Global::totalline = "";
QString Global::datetimeline = "";
QString Global::machinedetline = "";


/*QString Global::gstrLasttoken = 0;
QString Global::gqstrIpaddress = 0;
QString Global::gqstrUserName = 0;
QString Global::gqstrPassword = 0;*/

bool Global::isNetwork()
{
#if(SDK75)
    if(!g_ccmainObj->isGprs()&&!g_ccmainObj->isEthernet()&&!g_ccmainObj->isWifi())
    {
        return false;
    }
    return true;
#endif
#if(NativeCompile)
    return true;
#endif
}

