#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <threadclass.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    QTimer *t, *timer;
    ThreadClass *th_upld;
    int gprsfail_cnt, dberror_cnt, neterror_cnt;
    void Errorlog(QString errorStr);
    ~MainWindow();

public slots:
    void StartThread();
    void Thread_terminated(bool netstatus);
    void GPRS_Failed();
    void thread_Status(QString threadstatus);

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
