//#include "totalamt.h"
#include "ui_totalamt.h"
 //#include "modules.h"
#include "global.h"

#include <QtSql/QSqlQuery>

#include  <QtCore/QDebug>
 //#include "globalclass.h"

using namespace Global;

Totalamt::Totalamt(QWidget * parent):
  QDialog(parent),
  ui(new Ui::Totalamt) {
    ui->setupUi(this);

    //    #if(SDK75)
    //        setParent(MdiArea,Qt::Dialog);
    //    #endif

    //    setParent(gmdiareaObj);
    //    setWindowFlags(Qt::FramelessWindowHint);
    //    setFocusPolicy(Qt::NoFocus);
    //    setFixedSize(320,240);

    ui->pushButton_exit->setFocus();
    QSqlQuery qryUS;
    QDateTime datetime = QDateTime::currentDateTime();
    QString valdisp, currdate = datetime.toString("yyyy-MM-dd");
    QString currRepdate = datetime.toString("dd/MM/yyyy");

    if (gSqldatabase->SelectQuery("select sum(ticket_amt) from current_booking_master,ticket_transaction where current_booking_master.cb_ticket_id=ticket_transaction.ticket_id_no and ticket_user_name='" + UName + "' and ticket_trans_date='" + currdate + "' group by ticket_user_name", qryUS)) {
      if (qryUS.next()) {
        valdisp = "Rs. " + qryUS.value(0).toString() + "/-";
        ui->label_amt->setText(valdisp);
        ui->label_dt_caption->setText(currRepdate);
      }
    }
  }

void Totalamt::keyPressEvent(QKeyEvent * event) {
  if (event->key() == Qt::Key_Escape) {
   // if (QMessageBox::information(0, "Information", "Do you want to Close Application?", QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes) {
      this->hide();
      Modules * mod = new Modules(this, modlist);
      mod->show();
    //}
  }
}
void Totalamt::on_pushButton_exit_clicked() {
  this->close();
  Modules * mod = new Modules(this, modlist);
  mod->show();
}
Totalamt::~Totalamt() {
  delete ui;
}
