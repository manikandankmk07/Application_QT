/********************************************************************************
** Form generated from reading UI file 'loginclass.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINCLASS_H
#define UI_LOGINCLASS_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginClass
{
public:
    QGroupBox *groupBox;
    QLabel *label_in;
    QLineEdit *lineEdit_PW;
    QLabel *label;
    QLineEdit *lineEdit_UN;
    QLabel *label_2;
    QPushButton *pushButton_login;
    QPushButton *pushButton_cancel;

    void setupUi(QDialog *LoginClass)
    {
        if (LoginClass->objectName().isEmpty())
            LoginClass->setObjectName(QString::fromUtf8("LoginClass"));
        LoginClass->setEnabled(true);
        LoginClass->resize(320, 200);
        groupBox = new QGroupBox(LoginClass);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(0, 0, 320, 210));
        groupBox->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_in = new QLabel(groupBox);
        label_in->setObjectName(QString::fromUtf8("label_in"));
        label_in->setGeometry(QRect(0, 10, 320, 30));
        QFont font;
        font.setFamily(QString::fromUtf8("DejaVu Sans Mono"));
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        label_in->setFont(font);
        label_in->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label_in->setAlignment(Qt::AlignCenter);
        lineEdit_PW = new QLineEdit(groupBox);
        lineEdit_PW->setObjectName(QString::fromUtf8("lineEdit_PW"));
        lineEdit_PW->setGeometry(QRect(133, 103, 164, 34));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sans Serif"));
        font1.setPointSize(14);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        lineEdit_PW->setFont(font1);
        lineEdit_PW->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_PW->setInputMethodHints(Qt::ImhHiddenText|Qt::ImhNoAutoUppercase|Qt::ImhNoPredictiveText|Qt::ImhPreferNumbers);
        lineEdit_PW->setMaxLength(4);
        lineEdit_PW->setEchoMode(QLineEdit::Password);
        lineEdit_PW->setCursorPosition(0);
        lineEdit_PW->setReadOnly(false);
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 59, 106, 17));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Sans Serif"));
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setWeight(75);
        label->setFont(font2);
        lineEdit_UN = new QLineEdit(groupBox);
        lineEdit_UN->setObjectName(QString::fromUtf8("lineEdit_UN"));
        lineEdit_UN->setGeometry(QRect(133, 50, 164, 34));
        lineEdit_UN->setFont(font1);
        lineEdit_UN->setAutoFillBackground(false);
        lineEdit_UN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        lineEdit_UN->setLocale(QLocale(QLocale::English, QLocale::India));
        lineEdit_UN->setMaxLength(4);
        lineEdit_UN->setFrame(true);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 110, 106, 17));
        label_2->setFont(font2);
        pushButton_login = new QPushButton(groupBox);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));
        pushButton_login->setGeometry(QRect(124, 151, 90, 30));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Sans Serif"));
        font3.setPointSize(14);
        font3.setBold(true);
        font3.setWeight(75);
        pushButton_login->setFont(font3);
        pushButton_login->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
"selection-background-color: rgb(0, 0, 127);"));
        pushButton_cancel = new QPushButton(groupBox);
        pushButton_cancel->setObjectName(QString::fromUtf8("pushButton_cancel"));
        pushButton_cancel->setGeometry(QRect(221, 151, 90, 30));
        pushButton_cancel->setFont(font3);
        pushButton_cancel->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 170, 127);\n"
"selection-color: rgb(0, 0, 255);"));

        retranslateUi(LoginClass);

        QMetaObject::connectSlotsByName(LoginClass);
    } // setupUi

    void retranslateUi(QDialog *LoginClass)
    {
        LoginClass->setWindowTitle(QApplication::translate("LoginClass", "Form", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QString());
        label_in->setText(QApplication::translate("LoginClass", "Login", 0, QApplication::UnicodeUTF8));
        lineEdit_PW->setInputMask(QString());
        lineEdit_PW->setText(QString());
        label->setText(QApplication::translate("LoginClass", "User Name", 0, QApplication::UnicodeUTF8));
        lineEdit_UN->setInputMask(QString());
        label_2->setText(QApplication::translate("LoginClass", "Password", 0, QApplication::UnicodeUTF8));
        pushButton_login->setText(QApplication::translate("LoginClass", "Ok", 0, QApplication::UnicodeUTF8));
        pushButton_cancel->setText(QApplication::translate("LoginClass", "Cancel", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class LoginClass: public Ui_LoginClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINCLASS_H
