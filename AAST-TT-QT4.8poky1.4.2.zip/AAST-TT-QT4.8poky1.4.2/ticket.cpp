#include "global.h"
#include "ui_ticket.h"
#include <QtSql/QSqlQuery>
#include "QDebug"

using namespace Global;

Ticket::Ticket(QWidget *parent,QString moduleId) :
    QDialog(parent),
    ui(new Ui::Ticket)
{
    ui->setupUi(this);

    #if(SDK75)
        setParent(MdiArea,Qt::Dialog);
    #endif

    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);


//    setParent(gmdiareaObj);
//    setWindowFlags(Qt::FramelessWindowHint);
//    setFocusPolicy(Qt::NoFocus);
//    setFixedSize(320,240);

    ui->lineEdit_tic_qty->installEventFilter(this);
    {
        g_ccmainObj->setKeypadMode(ClanCor::eKeypadMode_NUMERIC);

        if(moduleId=="1")
            ui->label_3_mod_name->setText("ngUkhs; rd;djp");
        else if(moduleId=="2")
            ui->label_3_mod_name->setText("jhahu; rd;djp");
        else if(moduleId=="3")
            ui->label_3_mod_name->setText("rf;fuj;jho;thu;");
        else if(moduleId=="4")
            ui->label_3_mod_name->setText(",ju tif");
        else if(moduleId=="5")
            ui->label_3_mod_name->setText("fhl;lofp");
        else if(moduleId=="6")
            ui->label_3_mod_name->setText("fkyty;yp");
        else if(moduleId=="7")
            ui->label_3_mod_name->setText("Gz;luPfhf;\\");
        else if(moduleId=="8")
            ui->label_3_mod_name->setText("khupak;kd;");
        else if(moduleId=="9")
            ui->label_3_mod_name->setText("gpuk;kGuP");
        else if(moduleId=="10")
            ui->label_3_mod_name->setText("Re;juuh[h;");
        else if(moduleId=="11")
            ui->label_3_mod_name->setText("upg;Nghu;l;");
        else if(moduleId=="12")
            ui->label_3_mod_name->setText("njhif");

        m_strPresentDb_moduleId = presentDbid+"_"+moduleId;
    }
/**********Actual Coding to call upload function Start***************/
    t= new QTimer;
    t->setInterval(2000);
    t->setSingleShot(false);
    connect(t, SIGNAL(timeout()), this, SLOT(data_status()));
    t->start();

/**********Actual Coding to call upload function End***************/
    ui->label_3->hide();
    ui->lineEdit_tic_no->setFocus();
}

Ticket::~Ticket()
{
    delete ui;
}


void Ticket::creat_image_to_print()
{
    /*----------------------Additional--------------------------------*/
    qDebug()<<"IN BARCODE PRINTING================================================>>>3";
   ui->label_3->show();
   ui->label_3->raise();
   ui->label_3->setFocus();

    qDebug()<<"Inside Create Image To Print"<<lst_line_data<<lst_line_size;
    int Tot_size = 0;
    qDebug()<<"Chk 1";
    for(int i=0;i<lst_line_size.size();i++)
    {
        if(QString(lst_line_data.at(i)).left(3) == "~I~")
        {
            qDebug()<<"Chk 2";
            QString w1 = lst_line_size.at(i);
            qDebug()<<"Chk 3";
            int w = QString(w1.split(",").at(0)).toInt();
            int h = QString(w1.split(",").at(1)).toInt();
            Tot_size += (h+20)/2;
        }
        else
        {
            qDebug()<<"Chk 4";
            Tot_size += QString(lst_line_size.at(i)).toInt();
            qDebug()<<"Chk 4.5";
        }
    }
    qDebug()<<"Chk 5";
    Tot_size = Tot_size*2;
    qDebug()<<"test 1 with tot img size ===>>>"<<QString::number(Tot_size)<<" *** "<<QTime::currentTime().toString("HH-mm-ss-zzz");


    qDebug()<<"test 2 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
    QSize size;
    QImage image(384,Tot_size - 60, QImage::Format_Mono);        // Change the width and height here as needed if your letters get too big
    image.fill(1);
    qDebug()<<"test 3 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


    QPainter painter(&image);
    qDebug()<<"test 4 ===>>>கோவை"<<QTime::currentTime().toString("HH-mm-ss-zzz");

    QPen pen;
    pen.setWidth(40);
    pen.setBrush(Qt::black);
    painter.setPen(pen);
    //    qDebug()<<"test 6 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
    //    qDebug()<<"test 6.0 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


    int f_size=-36;
    //  QString F_name = "SUNDARAM-0806";


    for(int i=0;i<lst_line_data.size();i++)
    {
        qDebug()<<"image ===>>>"<<lst_line_data.at(i)<<lst_line_size.at(i)<<lst_is_bold.at(i)<<lst_is_italic.at(i)<<f_size;
        if(QString(lst_line_data.at(i)).left(3) == "~I~")
        {
            qDebug()<<"test 6 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


            QString w1 = lst_line_size.at(i);
            qDebug()<<"test 6.1 ===>>>"<<w1;


            int w = QString(w1.split(",").at(0)).toInt();
            int h = QString(w1.split(",").at(1)).toInt();


            i1.load(QString(lst_line_data.at(i)).remove("~I~"));

            int x1 = (w-h)/2;



            //            painter.drawImage(x1,f_size,i1.scaledToHeight(h));

            if(i==0)
            {
                painter.drawImage(x1,f_size,i1.scaledToHeight(h));

            }
            else
            {
                QString previous_data = lst_line_data.at(i-1);
                QString next_data = lst_line_data.at(i+1);
                QString next_size = lst_line_size.at(i+1);
                if(!previous_data.contains("~I~"))
                {
                    QString pre_size = lst_line_size.at(i-1);
                    qDebug()<<"test 6.1.0 ===>>>"<<w1;


                    int txt_size = pre_size.toInt();
                    painter.drawImage(x1,f_size+txt_size,i1.scaledToHeight(h));
                    if(next_data.contains("~I~"))
                    {
                        f_size = f_size+txt_size+40;
                    }
                }
                else
                {
                    painter.drawImage(x1,f_size,i1.scaledToHeight(h));
                    f_size += next_size.toInt();
                }

            }

            //            f_size += QString(QString(lst_line_size.at(i)).split(",").at(1)).toInt()+20;
            f_size += h;
            qDebug()<<"test 6.0 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
        }
        else
        {
            QFont font;
            font.setPointSize(QString(lst_line_size.at(i)).toInt());
            //            font.setFamily("SUNDARAM-0806");
            //            font.setFamily("TAM-Nambi");
            font.setFamily(lst_font_family.at(i));


            if(QString(lst_is_bold.at(i)).toInt() == 1)
                font.setBold(true);
            if(QString(lst_is_italic.at(i)).toInt() == 1)
                font.setItalic(true);
            //        qDebug()<<"test 7 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


            painter.setFont(font);


            QFontMetrics fm(painter.font());
            size.setWidth(384);


            QString lan_txt = QString(lst_line_data.at(i));
            //                qDebug()<<"test 8 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz")<<lan_txt;
            QString t1_lang = lst_line_data.at(i);
            //                qDebug()<<"lst_line_data ===>>>"<<t1_lang;


            //            painter.drawText(0,f_size,384,100,Qt::AlignCenter | Qt::TextWordWrap,QString::fromUtf8(t1_lang.toLatin1()));
            //            if(i==0)
            painter.drawText(0,f_size,384,150,Qt::AlignCenter,QString::fromUtf8(t1_lang.toLatin1()));


            //            if(i < lst_line_size.size()-1)
            f_size += (QString(lst_line_size.at(i)).toInt() * 1.5);
        }
    }
    f_size+=30;
    //    f_size=-20;
//    qDebug()<<"Image height ====>>"<<QString::number(f_size);
    size.setHeight(f_size);
//    qDebug()<<"test 13 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
    image.save("/tmp/logo_ticket.bmp","bmp");

    CPrinter print;
    print.setFontType(2);
//    qDebug()<<" Height : "<<image.height();

    QString barcodeval;
    barcodeval.clear();
    barcodeval=MachineID.right(3)+"_"+TickettransNo+"_"+TickettransId;

//    qDebug()<<"Barcode Value : "<<barcodeval;
//    qDebug()<<"Trans Details : "<<TransDetails;
//    qDebug()<<"Machine ID    : "<<MachineID;
//    qDebug()<<"User Name     : "<<UName;

    print.addImage(image,image.height(),true);
    print.addData("     "+TransDetails,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData("   ID:"+MachineID+"  User:"+UName,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
    print.addBarcode(barcodeval);
    print.paperFeed(12);

    if(print.print(false,false))
    {
        qDebug()<<"MainWindow ===>>>11";
        ui->lineEdit_tic_no->clear();
        ui->lineEdit_tic_qty->clear();
        ui->label_5_amt->clear();
        ui->lineEdit_tic_no->setFocus();
        ui->label_3->lower();
        ui->label_3->hide();
    }
    else{
        ui->lineEdit_tic_no->clear();
        ui->lineEdit_tic_qty->clear();
        ui->label_5_amt->clear();
        ui->lineEdit_tic_no->setFocus();
        ui->label_3->lower();
        ui->label_3->hide();
    }
}

void Ticket::add_image_data(QString r_const_imageDATA, QString font_family, int font_size, bool isBold, bool is_italic, PreView_Alignment preview_Align)
{
    qDebug()<<"MainWindow ===>>>9";

    //    lst_line_data.clear();
    //    lst_line_size.clear();
    lst_line_data << r_const_imageDATA.toLatin1();
    lst_line_size << QString::number(font_size).trimmed();
    lst_font_family << font_family;
    if(isBold)
        lst_is_bold << "1";
    else
        lst_is_bold << "0";

    if(is_italic)
        lst_is_italic << "1";
    else
        lst_is_italic << "0";

    qDebug()<<"MainWindow ===>>>10";
}

void Ticket::on_lineEdit_tic_no_returnPressed()
{
    QSqlQuery qryUS;

    TicketUniName.clear();
    QStringList str;
    str.clear();

    if(gSqldatabase->SelectQuery("select cb_ticket_id,cb_ticket_name,cb_ticket_amount,cb_ticket_print_type,cb_ticket_uni_name,cb_ticket_eng_name,cb_copies from current_booking_master where cb_ticket_status=1 and cb_ticket_category_id='"+ m_strPresentDb_moduleId +"' and ticket_id='"+ ui->lineEdit_tic_no->text() +"'",qryUS))
    {
        if(qryUS.next())
        {
            m_strTic_Id = qryUS.value(0).toString();
            ui->label_6_tic_name->setText(qryUS.value(1).toString());
            m_strticPrice = qryUS.value(2).toString();
            ticket_prnt = qryUS.value(3).toInt();
            str<<qryUS.value(4).toString();
            TicketEngName=qryUS.value(5).toString();
            TicketCopies=qryUS.value(6).toInt();

            qDebug()<<"unicode ====>>>"<<str;
        }
        else
        {
            if(QMessageBox::information(0,"Information","Invalid Ticke No. Want to Continue?",QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
            {
                ui->lineEdit_tic_no->setFocus();
                return;
            }
            else
            {
                this->close();
                Modules *mod=new Modules(this,modlist);
                mod->show();
            }
        }
        qryUS.clear();
    }

    if(ui->lineEdit_tic_qty->text().toInt()>0)
        ui->label_5_amt->setText(QString::number(m_strticPrice.toDouble()*ui->lineEdit_tic_qty->text().toDouble()));

    ui->lineEdit_tic_qty->setFocus();
}
void Ticket::data_status()
{
    qDebug()<<"\r Call thread status===>"<<gthreadstatus<<"<====";
    ui->labelTicket_status->setText(gthreadstatus);
}

void Ticket::on_lineEdit_tic_qty_returnPressed()
{
    if(m_strticPrice.toDouble()>0)
        ui->label_5_amt->setText(QString::number(m_strticPrice.toDouble()*ui->lineEdit_tic_qty->text().toDouble()));
    ui->pushButton_prnt->setFocus();
}
void Ticket::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
//        if(QMessageBox::information(0,"Information","Do you want to Close Application?",QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
//        {
            Modules *mod=new Modules(this,modlist);
            this->close();
            mod->show();
        //}
    }
}
/*bool Ticket::eventFilter(QObject *object, QEvent *event){

    if(event->type()==QEvent::FocusIn)
    {
        if(object==ui->lineEdit_tic_no || object==ui->lineEdit_tic_qty)
        {
            g_ccmainObj->setKeypadMode(ClanCor::eKeypadMode_NUMERIC);
        }
    }
    return false;
}*/

void Ticket::on_pushButton_prnt_clicked()
{
    qDebug()<<"\r ui->lineEdit_tic_qty->text().toInt()"<<ui->lineEdit_tic_qty->text().toInt();
    if(ui->lineEdit_tic_no->text().toInt() > 0  && ui->lineEdit_tic_qty->text().toInt() > 0 && ui->label_5_amt->text().toInt() > 0 )
    {
        if(SaveData())
        {
            qDebug()<<"To Printing Data";
            PrintData();
        }
        else{
            qDebug()<<"Save Failed";
        }
    }
    else
    {

        QMessageBox::about(0,"Ticket","Please Enter a valid Ticket ");
        ui->lineEdit_tic_no->clear();
        ui->lineEdit_tic_qty->clear();
        ui->label_5_amt->clear();
        ui->lineEdit_tic_no->setFocus();
    }
}
bool Ticket::SaveData()
{
    QDateTime datetime=QDateTime::currentDateTime();
    QSqlQuery qryTTno;
    QString TranscTime;
    double TicketNo;
    TicketNo = 1;

    qDebug()<<"Inside Data Save";

    if(gSqldatabase->SelectQuery("select max(ticket_trans_no)+ticket_qty from ticket_transaction where ticket_id='"+ui->lineEdit_tic_no->text()+"'",qryTTno))
    {
        if(qryTTno.next())
        {
            TicketNo = qryTTno.value(0).toDouble();
        }
    }
    //    qDebug()<<"TICKETNO"<<TicketNo;
    if(gSqldatabase->ExecuteCommand("insert into ticket_transaction(ticket_id,ticket_id_no,ticket_category_id,ticket_qty,ticket_user_name,ticket_machine_id,ticket_trans_no,ticket_trans_date,ticket_price,ticket_amt,UPLOAD_FLAG,ticket_trans_time) values ('"+ui->lineEdit_tic_no->text()+"','"+m_strTic_Id+"','"+m_strPresentDb_moduleId+"','"+ui->lineEdit_tic_qty->text()+"','"+UName+"','"+MachineID+"','"+QString::number(TicketNo) +"','"+datetime.toString("yyyy-MM-dd")+"','"+m_strticPrice+"','"+ui->label_5_amt->text()+ "',0,'"+datetime.toString("hh:mm:ss")+"')"))
        return true;
    else{
        QMessageBox::information(0,"Error","Local DB Insert not Successful");
        return false;
    }
}

bool Ticket::PrintData()
{
    qDebug()<<"Inside Print Data";

    QString t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;

    lst_line_size.clear();
    lst_line_data.clear();

    t1.clear();
    t2.clear();
    t3.clear();
    t4.clear();
    t5.clear();
    t6.clear();
    t7.clear();
    t8.clear();
    t9.clear();
    t10.clear();

    QDateTime datetime=QDateTime::currentDateTime();
    // QString ModuleName,TransDetails,TickettransNo,TickettransId;
    QSqlQuery qryTTno;

    // CPrinter prn;
    // prn.clear();

    if(gSqldatabase->SelectQuery("select ticket_unique_no,ticket_trans_no as ticket_no from ticket_transaction where ticket_trans_date=date() order by ticket_unique_no desc limit 1",qryTTno))
    {
        if(qryTTno.next())
        {
            TickettransNo = QString::number(qryTTno.value(0).toDouble());
            TickettransId = QString::number(qryTTno.value(1).toDouble());
        }
    }

    TransDetails = TickettransNo+" - "+datetime.toString("dd/MM/yy hh:mm")+" - "+TickettransId;

    /* construct the printing data format */
    if(ui->label_3_mod_name->text()=="ngUkhs; rd;djp")
        ModuleName="பெருமாள் சன்னதி";
    else if(ui->label_3_mod_name->text()=="jhahu; rd;djp")
        ModuleName="தாயார் சன்னதி";
    else if(ui->label_3_mod_name->text()=="rf;fuj;jho;thu;")
        ModuleName="சக்கரத்தாழ்வார்";
    else if(ui->label_3_mod_name->text()==",ju tif")
        ModuleName="இதர வகை";

    /*  else if(ui->label_3_mod_name->text()=="upg;Nghu;l;")
        ModuleName="ரிப்போர்ட்";
    else if(ui->label_3_mod_name->text()=="njhif")
        ModuleName="தொகை";*/

    //  prn.setNativeLanguage(CPrinter::e_NativeLanguage_TAMIL);

    qDebug()<<"Ticket Prntg. "<<ticket_prnt;
    qDebug()<<"Ticket Copies "<<TicketCopies;

    if(ticket_prnt==0)
    {
        for(int tickcopcnt=0;tickcopcnt<TicketCopies;tickcopcnt++)
        {
            if(ui->label_3_mod_name->text()=="ngUkhs; rd;djp" || ui->label_3_mod_name->text()=="jhahu; rd;djp" || ui->label_3_mod_name->text()=="rf;fuj;jho;thu;" || ui->label_3_mod_name->text()==",ju tif")
            {

                t1="ஶ்ரீ அரங்கநாதசுவாமி";
                t2="திருக்கோயில் - ஶ்ரீரங்கம்";
                t3="Sri Aranganathaswamy";
                t4="Thirukoil - Srirangam";
                t5=ModuleName;

                add_image_data(t1,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                add_image_data(t2,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                add_image_data(t3,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                add_image_data(t4,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                add_image_data(t5,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);

                if(ModuleName=="பெருமாள் சன்னதி"){
                    t6="Perumal Sannathi";
                }
                else if(ModuleName=="தாயார் சன்னதி"){
                    t6="Thayar Sannathi";
                }
                else if(ModuleName=="சக்கரத்தாழ்வார்"){
                    t6="Chakrathazhwar Sannathi";
                }
                else if(ModuleName=="இதர வகை"){
                    t6="Others";
                }
                else{
                    t6="";
                }
                add_image_data(t6,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
            }
            else{
                t5="";
                t6="";
                if(ui->label_3_mod_name->text()=="fhl;lofp"){
                    t1="அ/மி. காட்டழகிய சிங்கபெருமாள்";
                    t2="திருக்கோயில் - ஶ்ரீரங்கம்";
                    t3="A/M Kaattalagiya Singaperumal";
                    t4="Thirukoil - Srirangam";
                }
                else if(ui->label_3_mod_name->text()=="fkyty;yp"){
                    t1="அ/மி. கமலவல்லி நாச்சியார்";
                    t2="திருக்கோயில் - உறையூர்.";
                    t3="A/M Kamalavalli Natchiyar";
                    t4="Thirukoil - Uriyoor";
                }
                else if(ui->label_3_mod_name->text()=="Gz;luPfhf;\\"){
                    t1="அ/மி. புண்டரீகாக்ஷக் பெருமாள்";
                    t2="திருகோயில் - திருவெள்ளறை";
                    t3="A/M Pundareegashak Perumal";
                    t4="Thirukoil - Thiruvellarai";
                }
                else if(ui->label_3_mod_name->text()=="khupak;kd;"){
                    t1="அ/மி. மாரியம்மன் திருகோயில்";
                    t2="கீழன்பில்.";
                    t3="A/M Maariyamman Thirukoil";
                    t4="Keelanbil";
                }
                else if(ui->label_3_mod_name->text()=="gpuk;kGuP"){
                    t1="அ/மி. பிரம்மபுரீசுவரர் திருகோயில்";
                    t2="கீழன்பில்.";
                    t3="A/M Brammapureeswarar Thirukoil";
                    t4="Keelanbil";
                }
                else if(ui->label_3_mod_name->text()=="Re;juuh[h;"){
                    t1="அ/மி. சுந்தரராஜ பெருமாள்";
                    t2="திருகோயில் மேலன்பில்.";
                    t3="A/M Sundararaja Perumal";
                    t4="Thirukoil Melanbil";
                }
                else{

                }
                add_image_data(t1,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                add_image_data(t2,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                add_image_data(t3,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                add_image_data(t4,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                add_image_data(t5,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);
                add_image_data(t6,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);
            }
            //qDebug()<<"Ticket's UniCode Name : "<<TicketUniName;
            t7 = ui->label_6_tic_name->text();
            t8 = TicketEngName;
            t9 = ui->lineEdit_tic_qty->text()+" No(s).";
            t10 = "ரூ. "+ui->label_5_amt->text()+"/-";

            add_image_data(t7,"Bamini",20,false,false,PreViewAlignment_CENTER);
            add_image_data(t8,"DejaVu Sans Mono",20,false,false,PreViewAlignment_CENTER);
            add_image_data(t9,"DejaVu Sans Mono",26,false,false,PreViewAlignment_CENTER);
            add_image_data(t10,"TAM-Nambi",26,false,false,PreViewAlignment_CENTER);

            creat_image_to_print();
        }
        ui->lineEdit_tic_no->clear();
        ui->lineEdit_tic_qty->clear();
        ui->label_5_amt->clear();
        ui->lineEdit_tic_no->setFocus();
        return true;
    }
    else
    {
        for(int j=0; j<ui->lineEdit_tic_qty->text().toInt();j++)
        {
            for(int tickcopcnt=0;tickcopcnt<TicketCopies;tickcopcnt++)
            {
                if(ui->label_3_mod_name->text()=="ngUkhs; rd;djp" || ui->label_3_mod_name->text()=="jhahu; rd;djp" || ui->label_3_mod_name->text()=="rf;fuj;jho;thu;" || ui->label_3_mod_name->text()==",ju tif")
                {

                    t1="ஶ்ரீ அரங்கநாதசுவாமி";
                    t2="திருக்கோயில் - ஶ்ரீரங்கம்";
                    t3="Sri Aranganathaswamy";
                    t4="Thirukoil - Srirangam";
                    t5=ModuleName;

                    add_image_data(t1,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                    add_image_data(t2,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                    add_image_data(t3,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                    add_image_data(t4,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                    add_image_data(t5,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);

                    if(ModuleName=="பெருமாள் சன்னதி"){
                        t6="Perumal Sannathi";
                    }
                    else if(ModuleName=="தாயார் சன்னதி"){
                        t6="Thayar Sannathi";
                    }
                    else if(ModuleName=="சக்கரத்தாழ்வார்"){
                        t6="Chakrathazhwar Sannathi";
                    }
                    else if(ModuleName=="இதர வகை"){
                        t6="Others";
                    }
                    else{
                        t6="";
                    }
                    add_image_data(t6,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                }
                else{
                    t5="";
                    t6="";
                    if(ui->label_3_mod_name->text()=="fhl;lofp"){
                        t1="அ/மி. காட்டழகிய சிங்கபெருமாள்";
                        t2="திருக்கோயில் - ஶ்ரீரங்கம்";
                        t3="A/M Kaattalagiya Singaperumal";
                        t4="Thirukoil - Srirangam";
                    }
                    else if(ui->label_3_mod_name->text()=="fkyty;yp"){
                        t1="அ/மி. கமலவல்லி நாச்சியார்";
                        t2="திருக்கோயில் - உறையூர்.";
                        t3="A/M Kamalavalli Natchiyar";
                        t4="Thirukoil - Uriyoor";
                    }
                    else if(ui->label_3_mod_name->text()=="Gz;luPfhf;\\"){
                        t1="அ/மி. புண்டரீகாக்ஷக் பெருமாள்";
                        t2="திருகோயில் - திருவெள்ளறை";
                        t3="A/M Pundareegashak Perumal";
                        t4="Thirukoil - Thiruvellarai";
                    }
                    else if(ui->label_3_mod_name->text()=="khupak;kd;"){
                        t1="அ/மி. மாரியம்மன் திருகோயில்";
                        t2="கீழன்பில்.";
                        t3="A/M Maariyamman Thirukoil";
                        t4="Keelanbil";
                    }
                    else if(ui->label_3_mod_name->text()=="gpuk;kGuP"){
                        t1="அ/மி. பிரம்மபுரீசுவரர் திருகோயில்";
                        t2="கீழன்பில்.";
                        t3="A/M Brammapureeswarar Thirukoil";
                        t4="Keelanbil";
                    }
                    else if(ui->label_3_mod_name->text()=="Re;juuh[h;"){
                        t1="அ/மி. சுந்தரராஜ பெருமாள்";
                        t2="திருகோயில் மேலன்பில்.";
                        t3="A/M Sundararaja Perumal";
                        t4="Thirukoil Melanbil";
                    }
                    else{

                    }
                    add_image_data(t1,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                    add_image_data(t2,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
                    add_image_data(t3,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                    add_image_data(t4,"DejaVu Sans Mono",22,false,false,PreViewAlignment_CENTER);
                    add_image_data(t5,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);
                    add_image_data(t6,"TAM-Nambi",22,false,false,PreViewAlignment_CENTER);
                }
                //qDebug()<<"Ticket's UniCode Name : "<<TicketUniName;
                t7 = ui->label_6_tic_name->text();
                t8 = TicketEngName;
                t9 = ui->lineEdit_tic_qty->text()+" No(s).";
                t10 = "ரூ. "+ui->label_5_amt->text()+"/-";

                add_image_data(t7,"Bamini",20,false,false,PreViewAlignment_CENTER);
                add_image_data(t8,"DejaVu Sans Mono",20,false,false,PreViewAlignment_CENTER);
                add_image_data(t9,"DejaVu Sans Mono",26,false,false,PreViewAlignment_CENTER);
                add_image_data(t10,"TAM-Nambi",26,false,false,PreViewAlignment_CENTER);

                creat_image_to_print();
            }
        }
        //prnret = prn.print(false,false);
        //ui->label_check->setText("->"+prnret+"<-");
        //       prn.clear();
        ui->lineEdit_tic_no->clear();
        ui->lineEdit_tic_qty->clear();
        ui->label_5_amt->clear();
        ui->lineEdit_tic_no->setFocus();
        return true;
    }
}
void Ticket::on_pushButton_cancel_clicked(){
    this->close();
    Modules *mod=new Modules(this,modlist);
    mod->show();
}
