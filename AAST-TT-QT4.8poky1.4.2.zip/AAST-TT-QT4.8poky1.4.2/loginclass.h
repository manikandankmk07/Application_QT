#ifndef LOGINCLASS_H
#define LOGINCLASS_H

#include <QDialog>

namespace Ui {
class LoginClass;
}

class LoginClass : public QDialog
{
    Q_OBJECT

public:
    explicit LoginClass(QWidget *parent = 0);

    void keyPressEvent(QKeyEvent *event);
    void call_login();
    bool eventFilter(QObject *object, QEvent *event);

    ~LoginClass();

signals:
    void callthread();

private slots:
    void on_lineEdit_UN_returnPressed();
    void on_lineEdit_PW_returnPressed();
    void on_pushButton_login_clicked();
    void on_pushButton_cancel_clicked();

private:
    Ui::LoginClass *ui;
    QTimer *t;

};

#endif // LOGINCLASS_H
