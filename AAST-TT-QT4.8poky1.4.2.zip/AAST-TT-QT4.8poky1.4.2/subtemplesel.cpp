#include "ui_subtemplesel.h"
#include <QtSql/QSqlQuery>
#include <QDebug>
#include <QKeyEvent>
#include "global.h"
//#include <CPrinter>

//#include "modules.h"
//#include "templesel.h"
//#include <login.h>
//#include <globalclass.h>
//#include "globalclass.h"


using namespace Global;

Subtemplesel::Subtemplesel(QWidget *parent,QStringList module) :
    QDialog(parent),
    ui(new Ui::Subtemplesel)
{
    ui->setupUi(this);

//    #if(SDK75)
//        setParent(MdiArea,Qt::Dialog);
//    #endif

//    setParent(gmdiareaObj);
//    setWindowFlags(Qt::FramelessWindowHint);
//    setFocusPolicy(Qt::NoFocus);
//    setFixedSize(320,240);

    ui->pushButton_1->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->pushButton_4->setEnabled(false);
    ui->pushButton_5->setEnabled(false);
    ui->pushButton_6->setEnabled(false);

    int Ffocus = 0;
    for(int i=0;i<module.size();i++)
    {
        QString result =  module.at(i);
        if(result=="5")
        {
            ui->pushButton_1->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_1->setFocus();
                Ffocus=1;
            }
        }
        else if(result=="6")
        {
            ui->pushButton_2->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_2->setFocus();
                Ffocus=1;
            }
        }
        else if(result=="7")
        {
            ui->pushButton_3->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_3->setFocus();
                Ffocus=1;
            }
        }
        else if(result=="8")
        {
            ui->pushButton_4->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_4->setFocus();
                Ffocus=1;
            }
        }
        else if(result=="9")
        {
            ui->pushButton_5->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_5->setFocus();
                Ffocus=1;
            }
        }
        else if(result=="10")
        {
            ui->pushButton_6->setEnabled(true);
            if(Ffocus==0)
            {
                ui->pushButton_6->setFocus();
                Ffocus=1;
            }
        }
    }
    if(Ffocus)
        ui->pushButton_1->setFocus();
    /*else
        ui->label->setFocus();*/
}
Subtemplesel::~Subtemplesel()
{
    delete ui;
}

void Subtemplesel::creat_image_to_print()
{
    qDebug()<<"Inside Create Image To Print"<<lst_line_data<<lst_line_size;
    int Tot_size = 0;
    qDebug()<<"Chk 1";
    for(int i=0;i<lst_line_size.size();i++)
    {
        if(QString(lst_line_data.at(i)).left(3) == "~I~")
        {
            qDebug()<<"Chk 2";
            QString w1 = lst_line_size.at(i);
            qDebug()<<"Chk 3";
            int w = QString(w1.split(",").at(0)).toInt();
            int h = QString(w1.split(",").at(1)).toInt();
            Tot_size += (h+20)/2;
        }
        else
        {
            qDebug()<<"Chk 4";
            Tot_size += QString(lst_line_size.at(i)).toInt();
            qDebug()<<"Chk 4.5";
        }
    }
    qDebug()<<"Chk 5";
    Tot_size = Tot_size*2;
    qDebug()<<"test 1 with tot img size ===>>>"<<QString::number(Tot_size)<<" *** "<<QTime::currentTime().toString("HH-mm-ss-zzz");


    qDebug()<<"test 2 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
    QSize size;
    QImage image(384,Tot_size - 60, QImage::Format_Mono);        // Change the width and height here as needed if your letters get too big
    image.fill(1);
    qDebug()<<"test 3 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


    QPainter painter(&image);
    qDebug()<<"test 4 ===>>>கோவை"<<QTime::currentTime().toString("HH-mm-ss-zzz");

    QPen pen;
    pen.setWidth(40);
    pen.setBrush(Qt::black);
    painter.setPen(pen);
    //    qDebug()<<"test 6 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
    //    qDebug()<<"test 6.0 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


    int f_size=-36;
    //  QString F_name = "SUNDARAM-0806";


    for(int i=0;i<lst_line_data.size();i++)
    {
        qDebug()<<"image ===>>>"<<lst_line_data.at(i)<<lst_line_size.at(i)<<lst_is_bold.at(i)<<lst_is_italic.at(i)<<f_size;
        if(QString(lst_line_data.at(i)).left(3) == "~I~")
        {
            qDebug()<<"test 6 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");


            QString w1 = lst_line_size.at(i);
            qDebug()<<"test 6.1 ===>>>"<<w1;


            int w = QString(w1.split(",").at(0)).toInt();
            int h = QString(w1.split(",").at(1)).toInt();


            i1.load(QString(lst_line_data.at(i)).remove("~I~"));

            int x1 = (w-h)/2;



            //            painter.drawImage(x1,f_size,i1.scaledToHeight(h));

            if(i==0)
            {
                painter.drawImage(x1,f_size,i1.scaledToHeight(h));

            }
            else
            {
                QString previous_data = lst_line_data.at(i-1);
                QString next_data = lst_line_data.at(i+1);
                QString next_size = lst_line_size.at(i+1);
                if(!previous_data.contains("~I~"))
                {
                    QString pre_size = lst_line_size.at(i-1);
                    qDebug()<<"test 6.1.0 ===>>>"<<w1;


                    int txt_size = pre_size.toInt();
                    painter.drawImage(x1,f_size+txt_size,i1.scaledToHeight(h));
                    if(next_data.contains("~I~"))
                    {
                        f_size = f_size+txt_size+40;
                    }
                }
                else
                {
                    painter.drawImage(x1,f_size,i1.scaledToHeight(h));
                    f_size += next_size.toInt();
                }

            }

            //            f_size += QString(QString(lst_line_size.at(i)).split(",").at(1)).toInt()+20;
            f_size += h;
            qDebug()<<"test 6.0 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");
        }
        else
        {
            QFont font;
            font.setPointSize(QString(lst_line_size.at(i)).toInt());
            //            font.setFamily("SUNDARAM-0806");
            //            font.setFamily("TAM-Nambi");
            font.setFamily(lst_font_family.at(i));


            if(QString(lst_is_bold.at(i)).toInt() == 1)
                font.setBold(true);
            if(QString(lst_is_italic.at(i)).toInt() == 1)
                font.setItalic(true);
            //        qDebug()<<"test 7 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");

            painter.setFont(font);

            QFontMetrics fm(painter.font());
            size.setWidth(384);

            QString lan_txt = QString(lst_line_data.at(i));
            //                qDebug()<<"test 8 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz")<<lan_txt;
            QString t1_lang = lst_line_data.at(i);
            //                qDebug()<<"lst_line_data ===>>>"<<t1_lang;


            //            painter.drawText(0,f_size,384,100,Qt::AlignCenter | Qt::TextWordWrap,QString::fromUtf8(t1_lang.toLatin1()));
            //            if(i==0)
            painter.drawText(0,f_size,384,150,Qt::AlignCenter,QString::fromUtf8(t1_lang.toLatin1()));


            //            if(i < lst_line_size.size()-1)
            f_size += (QString(lst_line_size.at(i)).toInt() * 1.5);
        }
    }
    f_size+=30;
    //    f_size=-20;
    qDebug()<<"Image height ====>>"<<QString::number(f_size);
    size.setHeight(f_size);
    qDebug()<<"test 13 ===>>>"<<QTime::currentTime().toString("HH-mm-ss-zzz");

    image.save("/tmp/logo_report.bmp","bmp");

    CPrinter print;
    print.setFontType(2);
    print.addImage(image,image.height(),true);

    print.addData(totalline,CPrinter::eFontSize_BIG,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_LEFT);
    print.addData(datetimeline,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
    print.addData(machinedetline,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
    print.paperFeed(12);

    if(print.print(false,false))
    {
        qDebug()<<"MainWindow ===>>>11";
    }
}

void Subtemplesel::add_image_data(QString r_const_imageDATA, QString font_family, int font_size, bool isBold, bool is_italic, PreView_Alignment preview_Align)
{
    qDebug()<<"MainWindow ===>>>9";

    //    lst_line_data.clear();
    //    lst_line_size.clear();
    lst_line_data << r_const_imageDATA.toLatin1();
    lst_line_size << QString::number(font_size).trimmed();
    lst_font_family << font_family;
    if(isBold)
        lst_is_bold << "1";
    else
        lst_is_bold << "0";

    if(is_italic)
        lst_is_italic << "1";
    else
        lst_is_italic << "0";

    qDebug()<<"MainWindow ===>>>10";
}


void Subtemplesel::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        this->close();
        Templesel *widgetTemplesel=new Templesel(this,modlist);
        widgetTemplesel->show();
    }
}
void Subtemplesel::on_pushButton_1_clicked()
{
    moduleId="5";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_2_clicked()
{
    moduleId="6";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_3_clicked()
{
    moduleId="7";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_4_clicked()
{
    moduleId="8";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_5_clicked()
{
    moduleId="9";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_6_clicked()
{
    moduleId="10";
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_7_clicked()
{
    moduleId="11";
    ReportPrint();
    this->hide();
    widgetTicket=new Ticket(this,moduleId);
    widgetTicket->show();
}
void Subtemplesel::on_pushButton_8_clicked()
{
    moduleId="12";
    this->hide();
    widgetTotalamt=new Totalamt(this);
    widgetTotalamt->show();
}


bool Subtemplesel::ReportPrint(){
    QDateTime datetime=QDateTime::currentDateTime();
    QString currdate = datetime.toString("yyyy-MM-dd");
    QString distval,currRepdate = datetime.toString("dd/MM/yyyy");
    QSqlQuery qryTTno;

    QString t1,t2,t3,t4,t5,t6;

    lst_line_size.clear();
    lst_line_data.clear();

    t1.clear();
    t2.clear();
    t3.clear();
    t4.clear();
    t5.clear();
    t6.clear();

  //  prnt.setNativeLanguage(CPrinter::e_NativeLanguage_TAMIL);
    int slNo=1;
    double totval=0;

    //if(gSqldatabase->SelectQuery("select cb_ticket_name,min(ticket_trans_no),max(ticket_trans_no),sum(ticket_qty),ticket_price,sum(ticket_amt) from current_booking_master,ticket_transaction where current_booking_master.cb_ticket_id=ticket_transaction.ticket_id_no and ticket_user_name='"+UName+"' and ticket_trans_date='"+currdate+"' group by ticket_id_no",qryTTno))
    distval="";
    if(gSqldatabase->SelectQuery("select cb_ticket_category_name from current_booking_master,ticket_transaction where current_booking_master.cb_ticket_id=ticket_transaction.ticket_id_no and ticket_user_name='"+UName+"' and ticket_trans_date='"+currdate+"' group by ticket_id_no limit 1",qryTTno))
    {
        if(qryTTno.next())
        {
            distval = qryTTno.value(0).toString();
        }
    }

    if(distval=="ngUkhs; rd;djp" || distval=="jhahu; rd;djp" || distval=="rf;fuj;jho;thu;" || distval==",ju tif"){
        //prnt.addNativeData("அ/மி. ஶ்ரீ அரங்கநாதசுவாமி ",CPrinter::eLanguage_ALL,9,true,false);  //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("திருகோயில் - ஶ்ரீரங்கம்",CPrinter::eLanguage_ALL,9,true,false); //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="ஶ்ரீ அரங்கநாதசுவாமி";
        t2="திருக்கோயில் - ஶ்ரீரங்கம்";
    }
    else if(distval=="fhl;lofp"){
        //prnt.addNativeData("அ/மி. காட்டழகிய சிங்கபெருமாள்",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("திருகோயில் - ஶ்ரீரங்கம்.",CPrinter::eLanguage_ALL,9,true,false);  //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. காட்டழகிய சிங்கபெருமாள்";
        t2="திருகோயில் - ஶ்ரீரங்கம்.";
    }
    else if(distval=="fkyty;y"){
        //prnt.addNativeData("அ/மி. கமலவல்லி நாச்சியார்",CPrinter::eLanguage_ALL,9,true,false);  //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("திருக்கோயில் - உறையூர்.",CPrinter::eLanguage_ALL,9,true,false);  //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. கமலவல்லி நாச்சியார்";
        t2="திருக்கோயில் - உறையூர்.";
    }
    else if(distval=="Gz;luPfhf;\\"){
        //prnt.addNativeData("அ/மி. புண்டரீகாக்ஷக் பெருமாள்",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("திருகோயில் - திருவெள்ளறை.",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. புண்டரீகாக்ஷக் பெருமாள்";
        t2="திருகோயில் - திருவெள்ளறை.";
    }
    else if(distval=="khupak;kd;"){
        //prnt.addNativeData("அ/மி. மாரியம்மன் திருகோயில்",CPrinter::eLanguage_ALL,9,true,false);  //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("கீழன்பில்",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. மாரியம்மன் திருகோயில்";
        t2="கீழன்பில்";
    }
    else if(distval=="gpuk;kGuP"){
        //prnt.addNativeData("அ/மி. பிரம்மபுரீசுவரர் திருகோயில்",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData(" கீழன்பில்.",CPrinter::eLanguage_ALL,9,true,false);    //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. பிரம்மபுரீசுவரர் திருகோயில்";
        t2=" கீழன்பில்";
    }
    else if(distval=="Re;juuh[u;"){
        //prnt.addNativeData("அ/மி. சுந்தரராஜ பெருமாள்",CPrinter::eLanguage_ALL,9,true,false);   //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        //prnt.addNativeData("திருகோயில் மேலன்பில்.",CPrinter::eLanguage_ALL,9,true,false);      //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_CENTER);
        t1="அ/மி. சுந்தரராஜ பெருமாள்";
        t2="திருகோயில் மேலன்பில்.";
    }
    else{

    }

    t3="நாள் : "+currRepdate;
    t4=usFullNm;
    t5="வ. எண்.   டிக்கெட் பெயர்        ";
    t6="Start  End   Qty   Amt.  Total";

    add_image_data(t1,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
    add_image_data(t2,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
    add_image_data(t3,"TAM-Nambi",25,false,false,PreViewAlignment_CENTER);
    add_image_data(t4,"DejaVu Sans Mono",25,false,false,PreViewAlignment_CENTER);
    add_image_data(t5,"TAM-Nambi",20,false,false,PreViewAlignment_LEFT);
    add_image_data(t6,"DejaVu Sans Mono",17,false,false,PreViewAlignment_LEFT);

//    prnt.addNativeData("நாள் : "+currRepdate,CPrinter::eLanguage_ALL,9,true,false);    //,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
//    prnt.addData(usFullNm,CPrinter::eFontSize_MEDIUM,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
//    prnt.addNativeData("SlNo  டிக்கெட் பெயர்        ",CPrinter::eLanguage_ALL,9,true,false);     //,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_LEFT);
//    prnt.addData("  Start   End   Qty   Amt.    Total",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_LEFT);

    slNo=1;
    QString slNos;

    if(gSqldatabase->SelectQuery("select cb_ticket_uni_name as ticket_name,min(ticket_trans_no) as start_no,max(ticket_trans_no)+ticket_qty-1 as end_no,sum(ticket_qty) as qty,ticket_price,sum(ticket_amt) as tot_amt from current_booking_master,ticket_transaction where current_booking_master.cb_ticket_id=ticket_transaction.ticket_id_no and ticket_user_name='"+UName+"' and ticket_trans_date='"+currdate+"' group by ticket_id_no",qryTTno))
    {
        while(qryTTno.next())
        {
            totval = totval+qryTTno.value(5).toDouble();
            TicketUniName = qryTTno.value(0).toString();
            slNos= QString::number(slNo);

            add_image_data(slNos.leftJustified(6,' ')+"      "+TicketUniName.toUtf8(),"TAM-Nambi",19,false,false,PreViewAlignment_LEFT);
            add_image_data(qryTTno.value(1).toString().rightJustified(6,' ')+qryTTno.value(2).toString().rightJustified(6,' ')+qryTTno.value(3).toString().rightJustified(6,' ')+qryTTno.value(4).toString().rightJustified(6,' ')+qryTTno.value(5).toString().rightJustified(6,' '),"TAM-Nambi",21,false,false,PreViewAlignment_LEFT);

            //firstline[]=slNos.rightJustified(5,' ')+TicketUniName.toUtf8()+"    ";
            //secndline[]=qryTTno.value(1).toString().rightJustified(6,' ')+qryTTno.value(2).toString().rightJustified(6,' ')+qryTTno.value(3).toString().rightJustified(6,' ')+qryTTno.value(4).toString().rightJustified(6,' ')+qryTTno.value(5).toString().rightJustified(6,' ');
            //prnt.addData(slNos.rightJustified(5,' ')+TicketUniName.toUtf8()+"    ",CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            //prnt.addData(qryTTno.value(1).toString().rightJustified(6,' ')+qryTTno.value(2).toString().rightJustified(6,' ')+qryTTno.value(3).toString().rightJustified(6,' ')+qryTTno.value(4).toString().rightJustified(6,' ')+qryTTno.value(5).toString().rightJustified(6,' '),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
            slNo++;
        }

    }


    totalline = "           Total : "+QString::number(totval);
    datetimeline = "Date & Time:"+datetime.toString("dd/MM/yyyy hh:mm");
    machinedetline = "Machine ID:"+MachineID;

    qDebug()<<totalline;
    qDebug()<<datetimeline;
    qDebug()<<machinedetline;
    qDebug()<<"Before Print Image";

    creat_image_to_print();

//  QString totvals = QString::number(totval);
//  prnt.addData("           Total : "+totvals,CPrinter::eFontSize_BIG,CPrinter::eFontStyle_BOLD,CPrinter::eAlignment_LEFT);
//  prnt.addData("DateTime:"+datetime.toString("dd/MM/yyyy hh:mm"),CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_LEFT);
//  prnt.addData("   ID:"+MachineID,CPrinter::eFontSize_SMALL,CPrinter::eFontStyle_REGULAR,CPrinter::eAlignment_CENTER);
//  prnt.paperFeed(10);
//  prnt.print(false,false);
//  prnt.clear();
    return true;
}

