#include "loginclass.h"
#include "ui_loginclass.h"
#include "global.h"
#include <QtSql/QSqlQuery>
#include <QDebug>
#include <QMessageBox>

using namespace Global;

LoginClass::LoginClass(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginClass)
{
    qDebug()<<"Inside Login Class";

    ui->setupUi(this);

    #if(SDK75)
        setParent(MdiArea,Qt::Dialog);
    #endif

    setWindowFlags(Qt::FramelessWindowHint);
    setFocusPolicy(Qt::NoFocus);
    setFixedSize(320,240);

    g_ccmainObj->setKeypadMode(ClanCor::eKeypadMode_ALPHABETS);
    ui->lineEdit_PW->installEventFilter(this);
    ui->pushButton_login->setAutoDefault(true);
    ui->pushButton_cancel->setAutoDefault(true);
    ui->lineEdit_UN->setFocus();
}

LoginClass::~LoginClass()
{
    delete ui;
}

void LoginClass::on_lineEdit_UN_returnPressed()
{
    ui->lineEdit_PW->setFocus();
}
void LoginClass::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        //        if(QMessageBox::information(0,"Information","Do you want to Close Application?",QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
        //        {
        //g_ccmainObj->EnableGSMMessageBox(true);
        //            g_ccmainObj->disableGprs();
        //            this->close();
        //            qApp->closeAllWindows();
        //        }
    }
    /*if(event->key()==Qt::Key_F2)
    {
        g_ccmainObj->setAutoboot(true);
    }
    else*/
    if(event->key()==Qt::Key_F3)
    {
        //g_ccmainObj->setAutoboot(false);
        QCoreApplication::quit();
    }
}

bool LoginClass::eventFilter(QObject *object, QEvent *event){

    if(event->type()==QEvent::FocusIn)
    {
        if(object==ui->lineEdit_PW )   //|| object==ui->lineEdit_UN)
        {
            g_ccmainObj->setKeypadMode(ClanCor::eKeypadMode_NUMERIC);
        }
    }
    return false;
}



void LoginClass::on_lineEdit_PW_returnPressed()
{
    ui->pushButton_login->setFocus();
}
void LoginClass::call_login()
{
    ui->lineEdit_UN->clear();
    ui->lineEdit_PW->clear();
    ui->lineEdit_UN->setFocus();
}
void LoginClass::on_pushButton_login_clicked()
{
    QSqlQuery qry,qry1;
    QString dbPasswd,moduleOp;

    qDebug()<<"\r Module list1uyyuyi";
    //qDebug()<<"GPRS:"<<g_ccmainObj->EnableGPRSModule(true);


    //    #if(SDK75)
    //        qDebug()<<"Inside Login GPRS    :"<<g_ccmainObj->isGprs();
    //        qDebug()<<"Inside Login EtherNet:"<<g_ccmainObj->isEthernet();
    //    #endif

    qDebug()<<"GPRS:"<<g_ccmainObj->isGprs();
    qDebug()<<"EtherNet:"<<g_ccmainObj->isEthernet();

    //if(g_ccmainObj->isGprs() || g_ccmainObj->isEthernet())
    // {

    // select Present Database //

    qDebug()<<"Inside Mysql connect Fetch IF";

    if(gmysqldatabase->OpenMySqlConnection("automate_company"))
    {
        qDebug()<<"Inside 1";
        if(gmysqldatabase->SelectQueryMysql("select db_id from present_ticket_db limit 1",qry))
        {
            qDebug()<<"Inside 2";
            if(qry.next())
            {
                qDebug()<<"Inside 3";
                presentDbid = qry.value(0).toString();
            }
        }
        qry.clear();
    }
    else
    {
        qDebug()<<"Inside 4";
        QMessageBox::about(0,"Mysql",gErrorstr);
    }

    //QMessageBox::critical(0,"Present DBID",presentDbid);

    gmysqldatabase->CloseConnectionMysql();

    // Delete current booking master from local database
    gSqldatabase->ExecuteCommand("Delete from current_booking_master");
    gSqldatabase->ExecuteCommand("Delete from ticket_user_master");
    gSqldatabase->ExecuteCommand("Delete from present_ticket_db");

    if(gmysqldatabase->OpenMySqlConnection(presentDbid))
    {
        // Select current booking master from server database
        if(gmysqldatabase->SelectQueryMysql("select cb_ticket_id,cb_ticket_category_id,cb_ticket_category_name,cb_ticket_name,cb_ticket_uni_name,cb_ticket_eng_name,cb_ticket_amount,cb_ticket_print_type,cb_share_exp,cb_share_temple,cb_share_archagar,cb_share_barber,cb_share_total,cb_ticket_category_idno,cb_ticket_idno,cb_ticket_status,deleted,ticket_id,cb_copies,substr(cb_ticket_id,1,14) from `current_booking_master`",qry))
        {
            while(qry.next())
            {
                if(gSqldatabase->ExecuteCommand("insert into current_booking_master (cb_ticket_id,cb_ticket_category_id,cb_ticket_category_name,cb_ticket_name,cb_ticket_uni_name,cb_ticket_eng_name,cb_ticket_amount,cb_ticket_print_type,cb_share_exp,cb_share_temple,cb_share_archagar,cb_share_barber,cb_share_total,cb_ticket_category_idno,cb_ticket_idno,cb_ticket_status,deleted,ticket_id,cb_copies) values ('"+qry.value(0).toString()+"','"+qry.value(1).toString()+"','"+qry.value(2).toString()+"','"+qry.value(3).toString()+"','"+qry.value(4).toString()+"','"+qry.value(5).toString()+"','"+qry.value(6).toString()+"','"+qry.value(7).toString()+"','"+qry.value(8).toString()+"','"+qry.value(9).toString()+"','"+qry.value(10).toString()+"','"+qry.value(11).toString()+"','"+qry.value(12).toString()+"','"+qry.value(13).toString()+"','"+qry.value(14).toString()+"','"+qry.value(15).toString()+"','"+qry.value(16).toString()+"','"+qry.value(17).toString()+"','"+qry.value(18).toString()+"')"))
                {
                    qDebug()<<"successfully inserted current booking master";
                }
                if(gSqldatabase->ExecuteCommand("insert into present_ticket_db (db_id) values ('"+qry.value(19).toString()+"')"))
                {
                    qDebug()<<"successfully inserted present_ticket_db";
                }
            }
        }

        if(gmysqldatabase->SelectQueryMysql("select ttm_user_id,ttm_user_name,ttm_userid,ttm_user_passwd,ttm_modules_enable_id,ttm_last_updated_dt,ttm_maintemple,ttm_subtemple,deleted from `ticket_user_master`",qry1))
        {
            while(qry1.next())
            {
                if(gSqldatabase->ExecuteCommand("insert into ticket_user_master (ttm_user_id,ttm_user_name,ttm_userid,ttm_user_passwd,ttm_modules_enable_id,ttm_last_updated_dt,ttm_maintemple,ttm_subtemple,deleted) values ('"+qry1.value(0).toString()+"','"+qry1.value(1).toString()+"','"+qry1.value(2).toString()+"','"+qry1.value(3).toString()+"','"+qry1.value(4).toString()+"','"+qry1.value(5).toString()+"','"+qry1.value(6).toString()+"','"+qry1.value(7).toString()+"','"+qry1.value(8).toString()+"')"))
                {
                    qDebug()<<"successfully inserted current booking master";
                }
            }
        }
        //  }
        //  else
        //  {
        //      QMessageBox::about(0,"Mysql - "+presentDbid,gErrorstr);
        //  }
        //  ticket_user_master

        if(gmysqldatabase->SelectQueryMysql("select ttm_user_name,ttm_user_passwd,ttm_modules_enable_id,ttm_userid from ticket_user_master where ttm_user_name='"+ ui->lineEdit_UN->text() +"'",qry))
        {
            qDebug()<<"\r Module list1";
            if(qry.next())
            {
                dbPasswd = qry.value(1).toString();
                moduleOp = qry.value(2).toString();
                usFullNm = qry.value(3).toString();
                qDebug()<<"\r Module list"<<moduleOp;
                if(!(ui->lineEdit_PW->text()== dbPasswd))
                {
                    QMessageBox::critical(0,"Error"," Invalid Password");
                    ui->lineEdit_PW->setFocus();
                    return;
                }
                else
                {
                    qDebug()<<"\r start thread";
                    emit callthread();
                    modlist = moduleOp.split(',');
                    UName=ui->lineEdit_UN->text();
                    this->close();
                    Templesel *widgetTemplesel=new Templesel(this,modlist);
                    widgetTemplesel->show();
                }
            }
            else
            {
                QMessageBox::critical(0,"Error"," Invalid User Name");
                ui->lineEdit_UN->setFocus();
                return;
            }
        }
        qry.clear();
        gmysqldatabase->CloseConnectionMysql();
    }
    else
    {
        if(gSqldatabase->SelectQuery("select db_id from present_ticket_db limit 1",qry))
        {
            if(qry.next())
            {
                presentDbid = qry.value(0).toString();
            }
        }

        if(gSqldatabase->SelectQuery("select ttm_user_name,ttm_user_passwd,ttm_modules_enable_id,ttm_userid from ticket_user_master where ttm_user_name='"+ ui->lineEdit_UN->text() +"'",qry))
        {
            if(qry.next())
            {
                dbPasswd = qry.value(1).toString();
                moduleOp = qry.value(2).toString();
                usFullNm = qry.value(3).toString();
                qDebug()<<"\r Module list"<<moduleOp;
                if(!(ui->lineEdit_PW->text()== dbPasswd))
                {
                    QMessageBox::critical(0,"Error"," Invalid Password");
                    ui->lineEdit_PW->setFocus();
                    return;
                }
                else
                {
                    qDebug()<<"\r start thread";
                    //emit callthread();
                    modlist = moduleOp.split(',');
                    UName=ui->lineEdit_UN->text();
                    this->close();
                    Templesel *widgetTemplesel=new Templesel(this,modlist);
                    widgetTemplesel->show();
                }
            }
            else
            {
                QMessageBox::critical(0,"Error"," Invalid User Name");
                ui->lineEdit_UN->setFocus();
                return;
            }
        }
        qry.clear();
    }
}
void LoginClass::on_pushButton_cancel_clicked()
{
    //    if(QMessageBox::information(0,"Information","Do you want to Close Application?",QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
    //    {
    qDebug()<<"\r cancel clicked";

    //        g_ccmainObj->disableGprs();
    //        this->close();
    //        qApp->closeAllWindows();
    //    }
}
