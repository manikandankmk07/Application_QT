#ifndef TOTALAMT_H
#define TOTALAMT_H

#include <QDialog>
#include <QKeyEvent>

namespace Ui {
    class Totalamt;
}

class Totalamt : public QDialog
{
    Q_OBJECT

public:
    explicit Totalamt(QWidget *parent = 0);
    void keyPressEvent(QKeyEvent *event);
    ~Totalamt();

private:
    Ui::Totalamt *ui;

private slots:
    void on_pushButton_exit_clicked();

};

#endif // TOTALAMT_H
