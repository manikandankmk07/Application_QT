#ifndef GLOBAL_H
#define GLOBAL_H

#include <QMdiArea>
#include "cdatabase.h"
#include "cmysqldatabase.h"
#include "login.h"
#include "mainwindow.h"
#include "modules.h"
#include "subtemplesel.h"
#include "templesel.h"
#include "threadclass.h"
#include "ticket.h"
#include "totalamt.h"
#include "totalreport.h"
#include "loginclass.h"
#include <QLabel>

using namespace std;

#include <iostream>

#if(SDK75)
#include <GlobalClass.h>
#include <device_menu.h>

using namespace Globalclass;
#endif

namespace Global
{
extern QMdiArea* gmdiareaObj;
extern QLabel* glabelTitle;
extern LoginClass *loginObj;
extern CDatabase* gSqldatabase;
extern CMySqlDataBase* gmysqldatabase;
// extern CHH72xx *Chh_obj;
// extern CPrinter::E_NativeLanguage  g_e_Nativelanguage;
// extern Menu *menuObj;
// extern Server_Get_Post *Server_Get_PostObj;
// extern Settings *SettingsObj;
// extern PrinterSettings *PrinterSettingsObj;
// extern ThreadClass *threadObj;
extern Ticket *widgetTicket;
extern Totalamt *widgetTotalamt;
// extern Modules *widgetModules;
// extern Subtemplesel *widgetSubtemplesel;

extern QString MnmoduleId;
extern QString SbmoduleId;
extern QString moduleId;
extern QString presentDbid;
extern QStringList modlist;
extern QString UName;
extern QString MachineID;
extern QString TicketUniName;
extern QString TicketEngName;
extern int TicketCopies;
extern QString usFullNm;
extern int ticket_prnt;
extern QString gErrorstr;
extern QString gthreadstatus;

extern QString ModuleName;
extern QString TransDetails;
extern QString TickettransNo;
extern QString TickettransId;

extern QString totalline;
extern QString datetimeline;
extern QString machinedetline;

bool isNetwork();

//CPrinter  *m_PrintObj;
}

#endif // GLOBAL_H
