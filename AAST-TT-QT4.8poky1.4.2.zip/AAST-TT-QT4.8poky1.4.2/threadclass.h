#ifndef THREADCLASS_H
#define THREADCLASS_H

#include <QThread>
#include <QSqlQuery>

class ThreadClass : public QThread
{
    Q_OBJECT
public:
    explicit ThreadClass(QObject *parent = 0);
    void stop_Thread();
    bool gprsFlag;
    bool Thrd_flag;
    bool thredstatusflag;
    QString Errorstr;
    bool LastError;
    bool Uploadgpsflag;
    void errorHandler();
    bool uploadData();

    int nsize_bill_info,nticket_bill_no;

signals:
    void Thread_stopped(bool);
    void thread_status(QString);
//    void dataUploadstatus();
private:
     void run();
    
};

#endif // THREADCLASS_H
