#ifndef SUBTEMPLESEL_H
#define SUBTEMPLESEL_H

#include <QDialog>
//#include <ticket.h>
//#include <totalamt.h>
//#include <totalreport.h>
#include "global.h"

namespace Ui {
    class Subtemplesel;
}

class Subtemplesel : public QDialog
{
    Q_OBJECT

public:
    explicit Subtemplesel(QWidget *parent,QStringList subtemplesel);
    //Ticket *widgetTicket;
    //Totalamt *widgetTotalamt;
    //Totalreport *widgetTotalreport;
    //QString SbmoduleId;
    //QString firstline,secndline;

    QString moduleId;

    QStringList lst_line_data,lst_line_size,lst_is_bold,lst_is_italic,lst_font_family;
    enum PreView_Alignment
    {
        PreViewAlignment_LEFT ,      /**< Aligns with the left. */
        PreViewAlignment_CENTER ,    /**< Align with center. */
        PreViewAlignment_RIGHT       /**< Aligns with the right. */
    };

    void add_image_data(QString r_const_imageDATA,QString font_family,
                        int font_size, bool isBold, bool is_italic,
                        PreView_Alignment preview_Align = PreViewAlignment_LEFT);

    void creat_image_to_print();

    QImage i1;

    void keyPressEvent(QKeyEvent *event);

    ~Subtemplesel();

private:
    Ui::Subtemplesel *ui;
    bool ReportPrint();

private slots:
    void on_pushButton_1_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
};

#endif // SUBTEMPLESEL_H
