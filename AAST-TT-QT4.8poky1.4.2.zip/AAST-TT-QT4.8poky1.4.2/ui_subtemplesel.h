/********************************************************************************
** Form generated from reading UI file 'subtemplesel.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUBTEMPLESEL_H
#define UI_SUBTEMPLESEL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Subtemplesel
{
public:
    QPushButton *pushButton_1;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;

    void setupUi(QDialog *Subtemplesel)
    {
        if (Subtemplesel->objectName().isEmpty())
            Subtemplesel->setObjectName(QString::fromUtf8("Subtemplesel"));
        Subtemplesel->resize(320, 220);
        Subtemplesel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        pushButton_1 = new QPushButton(Subtemplesel);
        pushButton_1->setObjectName(QString::fromUtf8("pushButton_1"));
        pushButton_1->setGeometry(QRect(7, 37, 151, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("Bamini"));
        font.setPointSize(14);
        pushButton_1->setFont(font);
        pushButton_2 = new QPushButton(Subtemplesel);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(163, 37, 151, 41));
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(Subtemplesel);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(7, 83, 151, 41));
        pushButton_3->setFont(font);
        pushButton_4 = new QPushButton(Subtemplesel);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(163, 83, 151, 41));
        pushButton_4->setFont(font);
        pushButton_5 = new QPushButton(Subtemplesel);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(7, 129, 151, 41));
        pushButton_5->setFont(font);
        pushButton_6 = new QPushButton(Subtemplesel);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(163, 129, 151, 41));
        pushButton_6->setFont(font);
        pushButton_7 = new QPushButton(Subtemplesel);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setGeometry(QRect(7, 175, 151, 41));
        pushButton_7->setFont(font);
        pushButton_8 = new QPushButton(Subtemplesel);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setGeometry(QRect(163, 175, 151, 41));
        pushButton_8->setFont(font);

        retranslateUi(Subtemplesel);

        QMetaObject::connectSlotsByName(Subtemplesel);
    } // setupUi

    void retranslateUi(QDialog *Subtemplesel)
    {
        Subtemplesel->setWindowTitle(QApplication::translate("Subtemplesel", "Dialog", 0, QApplication::UnicodeUTF8));
        pushButton_1->setText(QApplication::translate("Subtemplesel", "fhl;lofp", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Subtemplesel", "fkyty;yp", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("Subtemplesel", "Gz;luPfhf;\\", 0, QApplication::UnicodeUTF8));
        pushButton_4->setText(QApplication::translate("Subtemplesel", "khupak;kd;", 0, QApplication::UnicodeUTF8));
        pushButton_5->setText(QApplication::translate("Subtemplesel", "gpuk;kGuP", 0, QApplication::UnicodeUTF8));
        pushButton_6->setText(QApplication::translate("Subtemplesel", "Re;juuh[u;", 0, QApplication::UnicodeUTF8));
        pushButton_7->setText(QApplication::translate("Subtemplesel", "upg;Nghu;l;", 0, QApplication::UnicodeUTF8));
        pushButton_8->setText(QApplication::translate("Subtemplesel", "njhif", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Subtemplesel: public Ui_Subtemplesel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUBTEMPLESEL_H
