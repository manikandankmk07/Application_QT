#ifndef TEMPLESEL_H
#define TEMPLESEL_H

#include <QDialog>
#include <modules.h>
#include <subtemplesel.h>

namespace Ui {
class Templesel;
}

class Templesel : public QDialog
{
    Q_OBJECT

public:
    explicit Templesel(QWidget *parent,QStringList templesel);
    //Modules *widgetModules;
    //Subtemplesel *widgetSubtemplesel;
    QString MnmoduleId;
    //QString SbmoduleId;
    void keyPressEvent(QKeyEvent *event);

    ~Templesel();


private:
    Ui::Templesel *ui;

private slots:
    void on_pushButton_1_clicked();
    void on_pushButton_2_clicked();

};

#endif // TEMPLESEL_H
