/********************************************************************************
** Form generated from reading UI file 'templesel.ui'
**
** Created: Tue Dec 17 12:29:36 2019
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEMPLESEL_H
#define UI_TEMPLESEL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Templesel
{
public:
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton_1;

    void setupUi(QWidget *Templesel)
    {
        if (Templesel->objectName().isEmpty())
            Templesel->setObjectName(QString::fromUtf8("Templesel"));
        Templesel->resize(320, 220);
        Templesel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 255, 0);"));
        label = new QLabel(Templesel);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(14, 30, 291, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("Sans Serif"));
        font.setPointSize(15);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        pushButton_2 = new QPushButton(Templesel);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(5, 162, 310, 43));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Bamini"));
        font1.setPointSize(18);
        font1.setBold(false);
        font1.setWeight(50);
        pushButton_2->setFont(font1);
        pushButton_1 = new QPushButton(Templesel);
        pushButton_1->setObjectName(QString::fromUtf8("pushButton_1"));
        pushButton_1->setGeometry(QRect(5, 85, 310, 43));
        pushButton_1->setFont(font1);

        retranslateUi(Templesel);

        QMetaObject::connectSlotsByName(Templesel);
    } // setupUi

    void retranslateUi(QWidget *Templesel)
    {
        Templesel->setWindowTitle(QApplication::translate("Templesel", "Form", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Templesel", "\340\256\244\340\256\277\340\256\260\340\257\201\340\256\225\340\257\215\340\256\225\340\257\213\340\256\265\340\256\277\340\256\262\340\257\215 \340\256\244\340\257\207\340\256\260\340\257\215\340\256\250\340\257\215\340\256\244\340\257\206\340\256\237\340\257\201\340\256\225\340\257\215\340\256\225", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Templesel", "cgNfhtpy;fs;", 0, QApplication::UnicodeUTF8));
        pushButton_1->setText(QApplication::translate("Templesel", "\340\256\270\340\257\215\340\256\260\340\257\200 uq;fk; jpUf;Nfhtpy;", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Templesel: public Ui_Templesel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEMPLESEL_H
